# -*- coding: utf-8 -*-
"""EA t3db (FIFA Street 2012) okuyucu/yazici.
PC (little-endian) ve Xbox360 (big-endian) destekler. Yerel dil dosyasi (eng_us) da ayni formattir.
Sikistirilmis metin alanlari (tip 13: 1 bayt uzunluk, tip 14: 2 bayt BE uzunluk) tek bir Huffman agaci kullanir.
"""
import struct, json, os

def _mk_crc():
    t = []
    for i in range(256):
        c = i << 24
        for _ in range(8):
            c = ((c << 1) ^ 0x04C11DB7) & 0xffffffff if c & 0x80000000 else (c << 1) & 0xffffffff
        t.append(c)
    def f(d, init=0xffffffff):
        c = init
        for b in d:
            c = ((c << 8) & 0xffffffff) ^ t[(c >> 24) ^ b]
        return c
    return f
crc32 = _mk_crc()

_META = {}
def load_meta(path):
    """XML'den uretilen json (make_meta.py). Dosya bazinda cache'lenir."""
    if path not in _META:
        _META[path] = json.load(open(path, encoding='utf-8'))
    return _META[path]

class Field:
    pass

class Table:
    def __init__(self, db, short, data, meta):
        self.db = db; self.short = short
        e = db.e
        self.hdr = bytearray(data[:36])
        self.nf = struct.unpack('<I', data[24:28])[0]
        self.rs = struct.unpack(e + 'I', data[4:8])[0]
        self.cnt = struct.unpack(e + 'I', data[16:20])[0] & 0xffff
        self.heaplen = struct.unpack(e + 'I', data[12:16])[0]
        m = meta.get(short)
        self.name = m['name'] if m else short
        mf = {f['s']: f for f in m['fields']} if m else {}
        self.fields = []; self.fmap = {}
        for i in range(self.nf):
            d = bytes(data[36 + 16 * i: 52 + 16 * i])
            t, bo, _, dep = struct.unpack(e + 'IIII', d)
            sh = d[8:12]; sh = (sh[::-1] if db.be else sh).decode('latin1')
            f = Field(); f.raw = d; f.short = sh; f.type = t; f.bo = bo; f.dep = dep
            mm = mf.get(sh)
            f.name = mm['n'] if mm else sh
            f.lo = mm['lo'] if mm else 0; f.hi = mm['hi'] if mm else 0
            f.key = mm['k'] if mm else False
            f.fk = mm['fk'] if mm else None
            if t in (13, 14):
                f.dep = 32          # heap ofseti (metin uzunlugu degil)
            self.fields.append(f); self.fmap[f.name] = f
        p = 36 + 16 * self.nf
        self.recs = [bytearray(data[p + i * self.rs: p + (i + 1) * self.rs]) for i in range(self.cnt)]
        p += self.cnt * self.rs
        self.heap = bytearray(data[p:p + self.heaplen])
        self.tail = bytes(data[p + self.heaplen:])      # tablo sonundaki sabit 4 bayt (oldugu gibi korunur)
        self.names = None
        if any(f.type in (13, 14) for f in self.fields):
            try:
                self.names = NameHeap(self)
            except (IndexError, ValueError):
                self.names = None   # agac cozulemedi: bu tablo salt-okunur ham veri olarak kalir

    def _raw(self, rec, f):
        be = self.db.be
        v = int.from_bytes(rec, 'big' if be else 'little')
        sh = len(rec) * 8 - f.bo - f.dep if be else f.bo
        return (v >> sh) & ((1 << f.dep) - 1)

    def _put(self, rec, f, x):
        be = self.db.be
        v = int.from_bytes(rec, 'big' if be else 'little')
        sh = len(rec) * 8 - f.bo - f.dep if be else f.bo
        mask = ((1 << f.dep) - 1) << sh
        v = (v & ~mask) | ((x << sh) & mask)
        rec[:] = v.to_bytes(len(rec), 'big' if be else 'little')

    def get(self, i, name):
        f = self.fmap[name]; rec = self.recs[i]
        x = self._raw(rec, f)
        if f.type == 0:
            b = x.to_bytes(f.dep // 8, 'big' if self.db.be else 'little')
            return b.split(b'\0')[0].decode('utf-8', 'replace')
        if f.type in (13, 14):
            if self.names is None: return '<cozulemedi>'
            return self.names.decode(x, 1 if f.type == 13 else 2)
        if f.type == 4:
            return struct.unpack('<f', x.to_bytes(4, 'little'))[0]
        return x + f.lo

    def set(self, i, name, val):
        f = self.fmap[name]; rec = self.recs[i]
        if f.type == 0:
            b = str(val).encode('utf-8'); n = f.dep // 8
            if len(b) > n - 1: raise ValueError('%s: en fazla %d bayt' % (name, n - 1))
            b = b + b'\0' * (n - len(b))
            self._put(rec, f, int.from_bytes(b, 'big' if self.db.be else 'little'))
        elif f.type == 13:
            # Oyuncu adi: heap'in sonuna eklemek oyunu cokertti. Bunun yerine mevcut girisin ustune yazilir.
            # Giris, bir sonraki girisin baslangicina kadar olan alani kaplar; yeni ad bundan uzunsa reddedilir.
            self.names.overwrite(self._raw(rec, f), str(val), name)
        elif f.type == 14:
            off = self.names.add_text(str(val), 2)
            self._put(rec, f, off)
        elif f.type == 4:
            self._put(rec, f, int.from_bytes(struct.pack('<f', float(val)), 'little'))
        else:
            x = int(val) - f.lo
            if x < 0 or x >= (1 << f.dep): raise ValueError('%s: %d..%d araliginda olmali' % (name, f.lo, f.lo + (1 << f.dep) - 1))
            self._put(rec, f, x)

    def row(self, i):
        return {f.name: self.get(i, f.name) for f in self.fields}

    def find(self, name, value):
        return [i for i in range(self.cnt) if self.get(i, name) == value]

    def new_record(self, like):
        self.recs.append(bytearray(self.recs[like])); self.cnt += 1
        return self.cnt - 1

    def serialize(self):
        e = self.db.e
        h = bytearray(self.hdr)
        h[12:16] = struct.pack(e + 'I', len(self.heap))
        h[16:20] = struct.pack(e + 'I', (self.cnt << 16) | self.cnt)
        h[32:36] = struct.pack(e + 'I', crc32(bytes(h[:32])))
        body = bytes(h) + b''.join(f.raw for f in self.fields) + b''.join(bytes(r) for r in self.recs) \
            + bytes(self.heap)
        # Tablo kuyrugu: 36. bayttan sona kadar olan bolgenin CRC-32/MPEG2 degeri (dosyanin endian'inda).
        # Converter ve oyun bunu dogrular; degisince guncellenmezse dosya reddedilir.
        pad = bytes(self.tail[:-4]) if len(self.tail) >= 4 else b''   # dolgu (varsa) oldugu gibi
        full = body + pad
        return full + struct.pack(e + 'I', crc32(full[36:]))


class NameHeap:
    """Sikistirilmis metin heap'i: [agac: 2 bayt/dugum (uzunluk/karakter)] + [uzunluk + huffman bitleri (MSB-first)]"""
    def __init__(self, table):
        self.t = table
        self.fs = [f for f in table.fields if f.type in (13, 14)]
        offs = [table._raw(r, f) for r in table.recs for f in self.fs]
        offs = [o for o in offs if o != 0xffffffff]
        self.tree_len = min(offs) if offs else 0
        H = table.heap
        self.U = [(H[i], H[i + 1]) for i in range(0, self.tree_len, 2)]
        self.codes = {}
        self._walk(0, '')

    def _walk(self, node, pref):
        for b in (0, 1):
            a, c = self.U[2 * node + b]
            if a == 0: self.codes[c] = pref + str(b)
            else: self._walk(a, pref + str(b))

    def decode(self, off, lenbytes=1):
        if off == 0xffffffff: return ''
        H = self.t.heap
        n = H[off] if lenbytes == 1 else struct.unpack('>H', bytes(H[off:off + 2]))[0]
        pos = (off + lenbytes) * 8; out = bytearray(); node = 0
        while len(out) < n:
            bit = (H[pos >> 3] >> (7 - (pos & 7))) & 1; pos += 1
            a, b = self.U[2 * node + bit]
            if a == 0: out.append(b); node = 0
            else: node = a
        return out.decode('utf-8', 'replace')

    def encode(self, text, lenbytes=1):
        b = text.encode('utf-8')
        bits = ''
        for c in b:
            if c not in self.codes:
                raise ValueError('%r karakteri bu dosyanin metin agacinda yok' % chr(c))
            bits += self.codes[c]
        bits += '0' * (-len(bits) % 8)
        body = int(bits, 2).to_bytes(len(bits) // 8, 'big') if bits else b''
        if lenbytes == 1:
            if len(b) > 255: raise ValueError('metin cok uzun')
            return bytes([len(b)]) + body
        return struct.pack('>H', len(b)) + body

    def _extent(self, off):
        if not hasattr(self, '_sorted'):
            self._sorted = sorted(set(self.t._raw(r, f) for r in self.t.recs for f in self.fs
                                      if self.t._raw(r, f) != 0xffffffff))
        import bisect
        i = bisect.bisect_right(self._sorted, off)
        end = self._sorted[i] if i < len(self._sorted) else len(self.t.heap)
        return end - off

    def overwrite(self, off, text, name=''):
        if off == 0xffffffff: raise ValueError('%s: bu kayitta isim yok' % name)
        data = self.encode(text, 1)
        ext = self._extent(off)
        if len(data) > ext:
            raise ValueError('"%s" adi cok uzun (orijinal alan %d bayt, yeni %d bayt). Daha kisa bir ad yaz.' % (text, ext, len(data)))
        H = self.t.heap
        H[off:off + ext] = data + bytes(ext - len(data))

    def add_text(self, text, lenbytes=1):
        """Metni heap'in sonuna ekler, ofset dondurur (ayni metin varsa onu kullanir)."""
        t = self.t
        cache = getattr(self, '_cache', None)
        if cache is None:
            cache = self._cache = {}
        key = (text, lenbytes)
        if key in cache: return cache[key]
        off = len(t.heap)
        t.heap += self.encode(text, lenbytes)
        cache[key] = off
        return off


class FifaDB:
    def __init__(self, data, meta):
        data = bytes(data)
        if data[:2] != b'DB': raise ValueError('DB dosyasi degil')
        self.be = data[4] == 1
        self.e = '>' if self.be else '<'
        e = self.e
        self.head = bytearray(data[:0x18])
        n = struct.unpack(e + 'I', data[0x10:0x14])[0]
        self.n = n
        self.base = 0x18 + 8 * n + 4
        lst = []
        for i in range(n):
            s = data[0x18 + 8 * i:0x1c + 8 * i]
            lst.append(((s[::-1] if self.be else s).decode('latin1'), struct.unpack(e + 'I', data[0x1c + 8 * i:0x20 + 8 * i])[0]))
        self.order = [s for s, _ in lst]
        self.tables = {}; self.by_name = {}
        for k, (s, o) in enumerate(lst):
            end = lst[k + 1][1] if k + 1 < n else len(data) - self.base
            t = Table(self, s, data[self.base + o:self.base + end], meta)
            self.tables[s] = t; self.by_name[t.name] = t

    def __getitem__(self, name):
        return self.by_name[name] if name in self.by_name else self.tables[name]

    def dump(self):
        e = self.e; be = self.be
        blobs = [self.tables[s].serialize() for s in self.order]
        head = bytearray(self.head)
        total = self.base + sum(len(b) for b in blobs)
        head[8:12] = struct.pack(e + 'I', total)
        head[0x14:0x18] = struct.pack(e + 'I', 0)
        head[0x14:0x18] = struct.pack(e + 'I', crc32(bytes(head[:0x14])))
        lst = bytearray(); off = 0
        for s, b in zip(self.order, blobs):
            lst += (s.encode('latin1')[::-1] if be else s.encode('latin1')) + struct.pack(e + 'I', off)
            off += len(b)
        return bytes(head[:0x14]) + struct.pack(e + 'I', crc32(bytes(head[:0x14]))) + bytes(lst) \
            + struct.pack(e + 'I', crc32(bytes(lst))) + b''.join(blobs)
