#!/usr/bin/env python3
"""FIFA Street (Xbox360) BIG4 + chunklzx modlama araci.
  fstool.py list    <data3.big> [filtre]
  fstool.py extract <data3.big> <filtre> <cikti_klasoru>   (chunklzx'i otomatik acar)
  fstool.py import  <data3.big> <klasor>                    (duzenlenmis dosyalari sikistirip big'e geri yazar)
Filtre: kucuk harf, yol icinde gecen metin (ornek: kit_1843  ya da  sceneassets/kit/)
"""
import sys, os, struct, shutil
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import chunklzx, chunklzx_enc

ALIGN = 0x40

def read_index(f):
    f.seek(0); h = f.read(16)
    if h[:4] != b'BIG4': raise SystemExit('BIG4 degil: %r' % h[:4])
    nfiles, hsize = struct.unpack('>II', h[8:16])
    f.seek(0); hdr = f.read(12 + hsize)
    ents = []; p = 16
    for _ in range(nfiles):
        off, size = struct.unpack('>II', hdr[p:p+8])
        e = hdr.index(b'\0', p + 8)
        ents.append(dict(idx=len(ents), pos=p, off=off, size=size, name=hdr[p+8:e].decode('latin1')))
        p = e + 1
    return h, ents

def match(ents, flt):
    flt = flt.lower().replace('\\', '/')
    return [e for e in ents if flt in e['name'].lower()]

def read_entry(big, name):
    """big icinden bir girdiyi okur (chunklzx ise acilmis halde). Yoksa None."""
    with open(big, 'rb') as f:
        h, ents = read_index(f)
        for e in ents:
            if e['name'].lower() == name.lower():
                f.seek(e['off']); d = f.read(e['size'])
                return chunklzx.decompress(d) if d[:8] == b'chunklzx' else d
    return None

def sync_bh(big, log=print, max_diff=10, dry=False):
    """.bh indeksini .big baslik tablosuyla esitler (ayni sirada, girdi basina 20 bayt: offset, boyut, 0, hash8)."""
    bh = os.path.splitext(big)[0] + '.bh'
    if not os.path.exists(bh): log('(.bh yok, atlandi)'); return 0
    with open(big, 'rb') as f: _, ents = read_index(f)
    d = bytearray(open(bh, 'rb').read())
    if d[:4] != b'ViV4': raise ValueError('.bh imzasi ViV4 degil: %r' % d[:4])
    n = struct.unpack('>I', d[8:12])[0]
    if n != len(ents) or len(d) != 16 + 20 * n: raise ValueError('.bh girdi sayisi/boyutu big ile uyusmuyor (%d / %d)' % (n, len(ents)))
    diff = []
    for e in ents:
        p = 16 + 20 * e['idx']
        if struct.unpack('>II', d[p:p+8]) != (e['off'], e['size']): diff.append(e)
    if len(diff) > max_diff: raise ValueError('.bh ile big arasinda %d fark var (beklenenden cok fazla); yanlis girdileri bozmamak icin durduruldu. Once: fstool.py checkbh <big>' % len(diff))
    if dry:
        log('.bh ile big arasinda %d fark var (toplam %d girdi)' % (len(diff), n))
        for e in diff[:20]:
            p = 16 + 20 * e['idx']; bo, bs = struct.unpack('>II', d[p:p+8])
            log('  #%d %s | big: 0x%X,%d | bh: 0x%X,%d' % (e['idx'], e['name'], e['off'], e['size'], bo, bs))
        return len(diff)
    if not diff: log('.bh zaten big ile ayni'); return 0
    if not os.path.exists(bh + '.bak'): shutil.copyfile(bh, bh + '.bak'); log('yedek alindi: ' + bh + '.bak')
    for e in diff:
        p = 16 + 20 * e['idx']; d[p:p+8] = struct.pack('>II', e['off'], e['size'])
        log('.bh guncellendi: %s' % e['name'])
    open(bh, 'wb').write(d); return len(diff)

def restore_entry(big, name, log=print):
    """Bir girdiyi .bak yedeginden geri yukler (orijinal bayt ve tablo degerleri), sonra .bh'yi esitler."""
    bak = big + '.bak'
    if not os.path.exists(bak): raise ValueError('yedek yok: ' + bak)
    with open(bak, 'rb') as fb:
        _, be = read_index(fb); o = [e for e in be if e['name'].lower() == name.lower()]
        if not o: raise ValueError('yedekte yok: ' + name)
        o = o[0]; fb.seek(o['off']); data = fb.read(o['size'])
    with open(big, 'r+b') as f:
        _, ents = read_index(f); c = [e for e in ents if e['name'].lower() == name.lower()][0]
        f.seek(o['off']); f.write(data)                                  # orijinal yerine orijinal bayt
        f.seek(c['pos']); f.write(struct.pack('>II', o['off'], o['size']))
    log('geri yuklendi: %s (offset 0x%X, %d bayt)' % (name, o['off'], o['size']))
    sync_bh(big, log)

def cmd_list(big, flt=''):
    with open(big, 'rb') as f:
        h, ents = read_index(f)
        for e in match(ents, flt):
            f.seek(e['off']); m = f.read(8)
            print('%10d  %-9s %s' % (e['size'], 'chunklzx' if m == b'chunklzx' else '', e['name']))

def cmd_extract(big, flt, out):
    n = 0
    with open(big, 'rb') as f:
        h, ents = read_index(f)
        for e in match(ents, flt):
            f.seek(e['off']); d = f.read(e['size'])
            if d[:8] == b'chunklzx': d = chunklzx.decompress(d)
            p = os.path.join(out, *e['name'].split('/'))
            os.makedirs(os.path.dirname(p), exist_ok=True)
            open(p, 'wb').write(d); n += 1; print('->', p)
    print(n, 'dosya')

def cmd_import(big, folder, log=print):
    items = []
    for root, _, files in os.walk(folder):
        for fn in files:
            p = os.path.join(root, fn)
            items.append((os.path.relpath(p, folder).replace(os.sep, '/'), p))
    return import_files(big, items, log)

def import_files(big, items, log=print, raw=False):
    """items: [(big_icindeki_yol, yerel_dosya_yolu)]"""
    bak = big + '.bak'
    if not os.path.exists(bak):
        log('yedek aliniyor: ' + bak); shutil.copyfile(big, bak)
    with open(big, 'r+b') as f:
        h, ents = read_index(f)
        byname = {e['name'].lower(): e for e in ents}
        f.seek(0, 2); fsize = f.tell()
        total_le = struct.unpack('<I', h[4:8])[0]; total_be = struct.unpack('>I', h[4:8])[0]
        n = 0
        for name, p in items:
            e = byname.get(name.lower())
            if not e: log('big icinde yok, atlandi: ' + name); continue
            new = open(p, 'rb').read()
            f.seek(e['off']); was = f.read(8)
            if was == b'chunklzx' and new[:8] != b'chunklzx' and not raw:
                f.seek(e['off']); hdr = f.read(0x28)
                log('sikistiriliyor: %s (%d bayt)' % (name, len(new))); new = chunklzx_enc.compress(new, hdr)
            if len(new) <= e['size']:
                f.seek(e['off']); f.write(new); off = e['off']
            else:
                f.seek(0, 2); end = f.tell()
                pad = (-end) % ALIGN; f.write(bytes(pad)); off = end + pad; f.write(new)
            f.seek(e['pos']); f.write(struct.pack('>II', off, len(new)))
            e['off'], e['size'] = off, len(new)   # ayni dosya tekrar yazilirsa dogru yerde olsun
            log('%s: yazildi, %d bayt @0x%X' % (name, len(new), off)); n += 1
        f.seek(0, 2); nsize = f.tell()
        if total_le == fsize: f.seek(4); f.write(struct.pack('<I', nsize)); log('toplam boyut alani (LE) guncellendi')
        elif total_be == fsize: f.seek(4); f.write(struct.pack('>I', nsize)); log('toplam boyut alani (BE) guncellendi')
        else: log('UYARI: header boyut alani dosya boyutuyla eslesmedi, degistirilmedi')
    log('%d dosya yazildi' % n)
    sync_bh(big, log)
    return n

if __name__ == '__main__':
    a = sys.argv[1:]
    if len(a) >= 2 and a[0] == 'list': cmd_list(a[1], a[2] if len(a) > 2 else '')
    elif len(a) == 4 and a[0] == 'extract': cmd_extract(*a[1:])
    elif len(a) == 3 and a[0] == 'import': cmd_import(*a[1:])
    elif len(a) == 4 and a[0] == 'put':     # put <big> <girdi_yolu> <dosya> [raw]  (test amacli)
        import_files(a[1], [(a[2], a[3])], raw=True)
    elif len(a) == 5 and a[0] == 'put':
        import_files(a[1], [(a[2], a[3])], raw=(a[4] == 'raw'))
    elif len(a) == 3 and a[0] == 'restore': restore_entry(a[1], a[2])
    elif len(a) == 2 and a[0] == 'checkbh': sync_bh(a[1], dry=True)
    elif len(a) == 2 and a[0] == 'syncbh': sync_bh(a[1])
    else: print(__doc__)
