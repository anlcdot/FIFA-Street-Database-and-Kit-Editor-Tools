import struct, sys

class Bits:
    def __init__(s, data): s.d=data; s.p=0; s.buf=0; s.n=0
    def need(s,k):
        while s.n<k:
            w = s.d[s.p]|(s.d[s.p+1]<<8) if s.p+1<len(s.d) else 0
            s.p+=2; s.buf=(s.buf<<16)|w; s.n+=16
    def peek(s,k):
        s.need(k); return (s.buf>>(s.n-k))&((1<<k)-1)
    def read(s,k):
        if k==0: return 0
        v=s.peek(k); s.n-=k; s.buf&=(1<<s.n)-1; return v
    def align(s):
        s.n -= s.n%16; s.buf&=(1<<s.n)-1

class Huff:
    def __init__(s, lens):
        s.maxl=max(lens) if lens else 0
        s.first=[0]*(s.maxl+2); s.cnt=[0]*(s.maxl+2); s.idx=[0]*(s.maxl+2)
        for l in lens:
            if l: s.cnt[l]+=1
        s.syms=[x for l in range(1,s.maxl+1) for x,ll in enumerate(lens) if ll==l]
        code=0; i=0
        for l in range(1,s.maxl+1):
            s.first[l]=code; s.idx[l]=i; i+=s.cnt[l]; code=(code+s.cnt[l])<<1
    def dec(s,b):
        code=0
        for l in range(1,s.maxl+1):
            code=(code<<1)|b.read(1)
            c=code-s.first[l]
            if 0<=c<s.cnt[l]: return s.syms[s.idx[l]+c]
        raise ValueError('bad huffman code')

def read_lens(b, lens, lo, hi):
    pre=Huff([b.read(4) for _ in range(20)])
    x=lo
    while x<hi:
        z=pre.dec(b)
        if z==17: r=b.read(4)+4; 
        elif z==18: r=b.read(5)+20
        elif z==19:
            r=b.read(1)+4; z=pre.dec(b); v=(lens[x]-z+17)%17
            for _ in range(r): lens[x]=v; x+=1
            continue
        else: lens[x]=(lens[x]-z+17)%17; x+=1; continue
        for _ in range(r): lens[x]=0; x+=1

def frames_of(payload):
    p=0; fr=[]
    while p+2<=len(payload):
        if payload[p]==0xFF: u,c=struct.unpack('>HH',payload[p+1:p+5]); p+=5
        else: c=struct.unpack('>H',payload[p:p+2])[0]; u=32768; p+=2
        if c==0: break
        fr.append((payload[p:p+c],u)); p+=c
    return fr

def decode_chunk(payload, out_size, wbits=17):
    slots={15:30,16:32,17:34,18:36,19:38,20:42,21:50}[wbits]
    extra=[0]*slots; base=[0]*slots
    for i in range(slots):
        extra[i]=0 if i<4 else min(17,(i>>1)-1)
    for i in range(1,slots): base[i]=base[i-1]+(1<<extra[i-1])
    nmain=256+slots*8
    fr=frames_of(payload)
    out=bytearray(); R=[1,1,1]
    mainl=[0]*nmain; lenl=[0]*249
    fi=0; b=Bits(fr[0][0]); first=True; remain=0; btype=0
    e8=0
    while len(out)<out_size:
        if remain==0:
            if first:
                if b.read(1): e8=(b.read(16)<<16)|b.read(16)
                first=False
            btype=b.read(3); remain=(b.read(16)<<8)|b.read(8)
            if btype==2:
                al=Huff([b.read(3) for _ in range(8)])
            if btype in(1,2):
                read_lens(b,mainl,0,256); read_lens(b,mainl,256,nmain)
                read_lens(b,lenl,0,249)
                mt=Huff(mainl); lt=Huff(lenl)
            elif btype==3:
                b.align(); R=[ (b.read(16)|(b.read(16)<<16)) for _ in range(3)]
            else: raise ValueError('bad block type %d'%btype)
        # run to frame boundary
        frame_end=min(((len(out)//32768)+1)*32768,out_size)
        run=min(remain,frame_end-len(out))
        done=0
        if btype==3:
            # raw bytes from current frame slice
            for _ in range(run):
                out.append(b.read(8)); 
            done=run
        else:
            while done<run:
                m=mt.dec(b)
                if m<256: out.append(m); done+=1; continue
                m-=256; ml=m&7; sl=m>>3
                if ml==7: ml+=lt.dec(b)
                ml+=2
                if sl==0: off=R[0]
                elif sl==1: off=R[1]; R[1]=R[0]; R[0]=off
                elif sl==2: off=R[2]; R[2]=R[0]; R[0]=off
                else:
                    if btype==2 and extra[sl]>=3:
                        v=b.read(extra[sl]-3) if extra[sl]>3 else 0
                        off=base[sl]-2+(v<<3)+al.dec(b)
                    elif extra[sl]>0: off=base[sl]-2+b.read(extra[sl])
                    else: off=1
                    R[2]=R[1]; R[1]=R[0]; R[0]=off
                if off>len(out): raise ValueError('offset %d beyond window at %d'%(off,len(out)))
                for _ in range(ml): out.append(out[-off])
                done+=ml
        remain-=done
        if len(out)%32768==0 and len(out)<out_size:
            fi+=1; b=Bits(fr[fi][0])
    return bytes(out[:out_size])

def decompress(d, wbits=17):
    assert d[:8]==b'chunklzx'
    ver,total,csize,nch,hsz=struct.unpack('>5I',d[8:28])
    pos=0x28; res=bytearray()
    for i in range(nch):
        while d[pos:pos+8]==bytes(8): pos+=8
        sz,flag=struct.unpack('>II',d[pos:pos+8])
        osz=min(csize,total-len(res))
        res+=decode_chunk(d[pos+8:pos+8+sz],osz,wbits)
        pos=(pos+8+sz+7)&~7
    return bytes(res)

if __name__=='__main__':
    d=open(sys.argv[1],'rb').read()
    wb=int(sys.argv[3]) if len(sys.argv)>3 else 17
    r=decompress(d,wb); open(sys.argv[2],'wb').write(r); print(len(r), r[:16].hex(' '), r[:16])
