# -*- coding: utf-8 -*-
"""FIFA Street: veritabanlarini oyun dosyalarindan cikarir, duzenlenmis halini ham olarak geri yazar.
Kullanim (oyun klasoru = data0.big'in oldugu klasor):
  python oyuna_yaz.py <oyun_klasoru> extract   -> calisma\\fifa_street_db.db ve calisma\\eng_us.db uretir
  python oyuna_yaz.py <oyun_klasoru> push      -> calisma\\ dosyalarini data0.big / locale.big'e ham yazar, .bh senkronlar
  python oyuna_yaz.py <oyun_klasoru> check     -> dosyalarin tutarliligini kontrol eder (yazmaz)
Yedek: ilk yazmadan once her big dosyasinin .bak kopyasi alinir (fstool). Sadece bir kez.
"""
import os, sys, struct, shutil
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import fstool, fifadb, chunklzx, chunklzx_enc

DATA0 = 'data0.big'
LOCALE = os.path.join('data', 'loc', 'locale.big')
DB_NAME = 'data/db/fifa_street_db.db'
LOC_NAME = 'data/loc/eng_us.db'

def read_entry_raw(big, name):
    with open(big, 'rb') as f:
        _, ents = fstool.read_index(f)
        e = [x for x in ents if x['name'].lower() == name.lower()]
        if not e: raise SystemExit('girdi yok: %s (%s)' % (name, big))
        e = e[0]; f.seek(e['off']); d = f.read(e['size'])
    return d

def extract_one(big, name, out):
    d = read_entry_raw(big, name)
    if d[:8] == b'chunklzx': d = chunklzx.decompress(d)
    open(out, 'wb').write(d)
    return len(d), d[4]

def paths(game):
    return (os.path.join(game, DATA0), os.path.join(game, DATA0[:-4] + '.bh'),
            os.path.join(game, LOCALE))

def main(game, cmd):
    work = os.path.join(HERE, 'calisma')
    os.makedirs(work, exist_ok=True)
    d0, bh0, loc = paths(game)
    db_file = os.path.join(work, 'fifa_street_db.db')
    loc_file = os.path.join(work, 'eng_us.db')
    if cmd == 'extract':
        n, be = extract_one(d0, DB_NAME, db_file)
        print('DB cikarildi: %s (%d bayt, %s)' % (db_file, n, 'Xbox/BE' if be == 1 else 'PC/LE'))
        n, be = extract_one(loc, LOC_NAME, loc_file)
        print('Yerel dil cikarildi: %s (%d bayt, %s)' % (loc_file, n, 'Xbox/BE' if be == 1 else 'PC/LE'))
    elif cmd == 'show':
        import time
        pcm = fifadb.load_meta(os.path.join(HERE, 'fifadb_meta.json'))
        enm = fifadb.load_meta(os.path.join(HERE, 'eng_us_meta.json'))
        db = fifadb.FifaDB(open(db_file, 'rb').read(), pcm)
        lc = fifadb.FifaDB(open(loc_file, 'rb').read(), enm)
        lt = lc.tables['vCJG']
        vals = {lt.get(i, 'stringid'): lt.get(i, 'sourcetext') for i in range(lt.cnt)}
        print('calisma\\fifa_street_db.db  degisiklik: %s' % time.ctime(os.path.getmtime(db_file)))
        print('  takim 1 (teamid=%d) PC adi   : %s' % (db['teams'].get(0, 'teamid'), db['teams'].get(0, 'teamname')))
        print('  oyuncu 1 overall             : %s' % db['players'].get(0, 'overallrating'))
        print('calisma\\eng_us.db          degisiklik: %s' % time.ctime(os.path.getmtime(loc_file)))
        print('  TeamName_1 (oyunda gorunen)  : %s' % vals.get('TeamName_1'))
        print('  TeamName_2                   : %s' % vals.get('TeamName_2'))
        print('oyun klasorundeki data0.big   : %s' % time.ctime(os.path.getmtime(d0)))
        print('oyun klasorundeki locale.big  : %s' % time.ctime(os.path.getmtime(loc)))
    elif cmd == 'check':
        for f in (db_file, loc_file):
            print(f, 'var' if os.path.exists(f) else 'YOK', os.path.getsize(f) if os.path.exists(f) else '')
        fstool.sync_bh(d0, dry=True)
    elif cmd == 'push':
        if not (os.path.exists(db_file) and os.path.exists(loc_file)):
            raise SystemExit('once extract calistir; calisma\\ klasorunde dosyalar yok')
        # yazmadan once dogrula: dosyalar acilabiliyor mu
        fifadb.FifaDB(open(db_file, 'rb').read(), fifadb.load_meta(os.path.join(HERE, 'fifadb_meta.json')))
        fifadb.FifaDB(open(loc_file, 'rb').read(), fifadb.load_meta(os.path.join(HERE, 'eng_us_meta.json')))
        # Veritabani oyunun bekledigi gibi chunklzx (sikistirilmis) olarak yazilir.
        orig_entry = read_entry_raw(d0, DB_NAME)
        hdr = orig_entry[:0x28]
        plain = open(db_file, 'rb').read()
        comp = chunklzx_enc.compress(plain, hdr)
        if chunklzx.decompress(comp) != plain:
            raise SystemExit('HATA: sikistirma dogrulamasi basarisiz, hicbir sey yazilmadi')
        comp_file = os.path.join(work, 'fifa_street_db.chunk')
        open(comp_file, 'wb').write(comp)
        fstool.import_files(d0, [(DB_NAME, comp_file)], raw=True)
        # Yerel dil orijinalde ham oldugu icin ham yazilir.
        fstool.import_files(loc, [(LOC_NAME, loc_file)], raw=True)
        print('Tamam. Oyunu deneyebilirsin.')
    else:
        raise SystemExit(__doc__)

if __name__ == '__main__':
    if len(sys.argv) != 3: raise SystemExit(__doc__)
    main(sys.argv[1], sys.argv[2])
