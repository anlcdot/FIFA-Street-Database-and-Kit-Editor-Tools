# -*- coding: utf-8 -*-
"""FIFA Street DB Yoneticisi: takimlar ve oyuncular.
Kullanim: python dbmanager.py  (dosya yollari ust kisimdan secilir; ayni klasorde varsayilanlar aranir)
"""
import os, sys, tkinter as tk
from tkinter import ttk, filedialog, messagebox
import dbmodel, json
import oyuna_yaz

HERE = os.path.dirname(os.path.abspath(__file__))
CALISMA = os.path.join(HERE, 'calisma')
AYAR = os.path.join(HERE, 'oyun_ayar.json')
PLAYER_NUM = ['overallrating', 'preferredjerseynumber', 'height', 'weight', 'fsspeed', 'fsshooting',
              'fspassing', 'fsdribbling', 'fsdefending', 'fsgk', 'fsathleticism', 'preferredposition1',
              'preferredposition2', 'nationality', 'birthdate', 'playerjointeamdate', 'skillmoves', 'weakfootabilitytypecode']
TEAM_NUM = ['teamcolor1r', 'teamcolor1g', 'teamcolor1b', 'teamcolor2r', 'teamcolor2g', 'teamcolor2b',
            'rivalteam', 'jerseytype', 'defmentality', 'domesticprestige']


class App(tk.Tk):
    def __init__(self, pc, meta, loc, locmeta):
        super().__init__()
        self.title('FIFA Street DB Yöneticisi')
        self.geometry('980x640')
        self.model = None
        self.paths = dict(pc=pc, meta=meta, loc=loc, locmeta=locmeta)
        self._build()
        # Acilista: calisma dosyalari varsa onlari yukle; yoksa hicbir sey sorma, once 'Oyundan cikar' denir.
        if pc and os.path.exists(pc):
            self.load()
        else:
            self.status.set("Önce 'Oyundan çıkar' ile oyunun dosyalarını çıkar.")

    # ---------- arayuz ----------
    def _build(self):
        top = ttk.Frame(self); top.pack(fill='x', padx=8, pady=6)
        ttk.Button(top, text='PC db seç', command=lambda: self.pick('pc')).pack(side='left')
        ttk.Button(top, text='Yerel dil (eng_us) seç', command=lambda: self.pick('loc')).pack(side='left', padx=4)
        ttk.Button(top, text='Yükle', command=self.load).pack(side='left', padx=4)
        ttk.Button(top, text='Kaydet', command=self.save).pack(side='right')
        ttk.Button(top, text='Oyuna yaz', command=self.do_push).pack(side='right', padx=4)
        ttk.Button(top, text='Oyundan çıkar', command=self.do_extract).pack(side='right', padx=4)
        self.status = tk.StringVar(value='Dosya yüklenmedi.')
        ttk.Label(self, textvariable=self.status).pack(fill='x', padx=8)
        self.nb = ttk.Notebook(self); self.nb.pack(fill='both', expand=True, padx=8, pady=6)
        self.tab_teams = ttk.Frame(self.nb); self.tab_players = ttk.Frame(self.nb)
        self.nb.add(self.tab_teams, text='Takımlar'); self.nb.add(self.tab_players, text='Oyuncular')
        self._build_teams(); self._build_players()

    def _scroll_form(self, parent):
        cv = tk.Canvas(parent, highlightthickness=0)
        sb = ttk.Scrollbar(parent, orient='vertical', command=cv.yview)
        frm = ttk.Frame(cv)
        frm.bind('<Configure>', lambda e: cv.configure(scrollregion=cv.bbox('all')))
        cv.create_window((0, 0), window=frm, anchor='nw')
        cv.configure(yscrollcommand=sb.set)
        cv.pack(side='left', fill='both', expand=True); sb.pack(side='right', fill='y')
        return frm

    def _build_teams(self):
        left = ttk.Frame(self.tab_teams); left.pack(side='left', fill='y', padx=6, pady=6)
        self.team_list = tk.Listbox(left, width=34, exportselection=False)
        self.team_list.pack(fill='y', expand=True); self.team_list.bind('<<ListboxSelect>>', self.on_team)
        wrap = ttk.Frame(self.tab_teams); wrap.pack(side='left', fill='both', expand=True, padx=6, pady=6)
        self.tform = self._scroll_form(wrap)
        self.team_vars = {}

    def _build_players(self):
        top = ttk.Frame(self.tab_players); top.pack(fill='x', padx=6, pady=4)
        ttk.Label(top, text='Takım:').pack(side='left')
        self.team_filter = ttk.Combobox(top, state='readonly', width=36)
        self.team_filter.pack(side='left', padx=4); self.team_filter.bind('<<ComboboxSelected>>', lambda e: self.fill_players())
        left = ttk.Frame(self.tab_players); left.pack(side='left', fill='y', padx=6)
        self.player_list = tk.Listbox(left, width=40, exportselection=False)
        self.player_list.pack(fill='y', expand=True); self.player_list.bind('<<ListboxSelect>>', self.on_player)
        wrap = ttk.Frame(self.tab_players); wrap.pack(side='left', fill='both', expand=True, padx=6, pady=6)
        self.pform = self._scroll_form(wrap)
        self.pvars = {}

    # ---------- oyun klasoru / cikarma / yazma ----------
    def game_dir(self):
        g = None
        try:
            g = json.load(open(AYAR, encoding='utf-8')).get('oyun')
        except Exception:
            g = None
        if not g or not os.path.isdir(g):
            g = filedialog.askdirectory(title='Oyun klasörünü seç (data0.big ve data\\loc içeren klasör)')
            if not g: return None
            try: json.dump({'oyun': g}, open(AYAR, 'w', encoding='utf-8'))
            except Exception: pass
        return g

    def do_extract(self):
        g = self.game_dir()
        if not g: return
        try:
            oyuna_yaz.main(g, 'extract')
        except SystemExit as e:
            messagebox.showerror('Çıkarma hatası', str(e)); return
        except Exception as e:
            messagebox.showerror('Çıkarma hatası', str(e)); return
        self.paths['pc'] = os.path.join(CALISMA, 'fifa_street_db.db')
        self.paths['loc'] = os.path.join(CALISMA, 'eng_us.db')
        self.load()
        self.status.set('Oyundan çıkarıldı ve yüklendi. Düzenleyebilirsin.')

    def do_push(self):
        g = self.game_dir()
        if not g: return
        if not self.model:
            messagebox.showerror('Hata', 'Önce dosyaları çıkar ve yükle.'); return
        if not messagebox.askyesno('Oyuna yaz', 'Değişiklikler kaydedilip oyun dosyalarına yazılacak. Oyun kapalı olmalı. Devam?'):
            return
        try:
            self.save()
            oyuna_yaz.main(g, 'push')
        except SystemExit as e:
            messagebox.showerror('Yazma hatası', str(e)); return
        except Exception as e:
            messagebox.showerror('Yazma hatası', str(e)); return
        self.status.set('Oyuna yazıldı. Oyunu açıp kontrol edebilirsin.')
        messagebox.showinfo('Tamam', 'Oyuna yazıldı. Oyunu açıp kontrol edebilirsin.')

    # ---------- islemler ----------
    def pick(self, which):
        p = filedialog.askopenfilename(title='Dosya seç', filetypes=[('DB', '*.db'), ('Tümü', '*.*')])
        if p:
            self.paths['pc' if which == 'pc' else 'loc'] = p

    def load(self):
        pc = self.paths['pc']; loc = self.paths['loc']
        if not pc or not os.path.exists(pc):
            messagebox.showerror('Hata', 'PC db bulunamadı.'); return
        try:
            meta = os.path.join(HERE, 'fifadb_meta.json'); lmeta = os.path.join(HERE, 'eng_us_meta.json')
            self.model = dbmodel.FifaModel(pc, meta, loc if loc and os.path.exists(loc) else None, lmeta)
        except Exception as ex:
            messagebox.showerror('Yükleme hatası', str(ex)); return
        m = self.model
        self.team_list.delete(0, 'end')
        self.team_rows = []
        for tid, row in m.team_ids():
            self.team_list.insert('end', '%4d  %s' % (tid, m.team_pc_name(row)))
            self.team_rows.append((tid, row))
        names = ['Tümü'] + ['%d %s' % (tid, m.team_pc_name(row)) for tid, row in self.team_rows]
        self.team_filter['values'] = names; self.team_filter.current(0)
        self.fill_players()
        self.status.set('Yüklendi: %s%s' % (os.path.basename(pc),
                        ' + ' + os.path.basename(loc) if self.model.loc else ' (yerel dil yok)'))

    def on_team(self, _=None):
        sel = self.team_list.curselection()
        if not sel: return
        tid, row = self.team_rows[sel[0]]
        for w in self.tform.winfo_children(): w.destroy()
        m = self.model; t = m.pc['teams']
        self.team_vars = {}
        r = 0
        def add(label, var, key):
            nonlocal r
            ttk.Label(self.tform, text=label).grid(row=r, column=0, sticky='w', padx=4, pady=2)
            ttk.Entry(self.tform, textvariable=var, width=36).grid(row=r, column=1, sticky='w', padx=4)
            r += 1
        ttk.Label(self.tform, text='teamid: %d' % tid, font=('', 9, 'bold')).grid(row=r, column=0, columnspan=2, sticky='w'); r += 1
        v = tk.StringVar(value=t.get(row, 'teamname')); self.team_vars['__pcname'] = (v, row)
        add('PC takım adı (teamname)', v, 'teamname')
        v = tk.StringVar(value=m.team_loc_name(tid) or ''); self.team_vars['__locname'] = (v, tid)
        add('Oyunda görünen ad (TeamName_%d)' % tid, v, 'loc')
        v = tk.StringVar(value=''); self.team_vars['__abbr'] = (v, tid)
        add('Kısaltma (3 harf, boş = ilk 3 harf)', v, 'abbr')
        for f in TEAM_NUM:
            if f not in t.fmap: continue
            v = tk.StringVar(value=str(t.get(row, f))); self.team_vars[f] = (v, row)
            add(f, v, f)
        self.team_row_current = (tid, row)
        ttk.Button(self.tform, text='Bu takımı uygula', command=self.apply_team).grid(row=r, column=0, columnspan=2, pady=8)

    def apply_team(self):
        m = self.model; tid, row = self.team_row_current
        try:
            for k, (v, rr) in self.team_vars.items():
                val = v.get()
                if k == '__pcname': m.pc['teams'].set(row, 'teamname', val)
                elif k == '__locname':
                    abbr = self.team_vars['__abbr'][0].get().strip() or None
                    if m.loc and m.team_loc_name(tid) is not None: m.set_team_loc_name(tid, val, abbr)
                elif k == '__abbr': continue
                else: m.pc['teams'].set(row, k, int(val))
            self.team_list.delete(row_index := self.team_list.curselection()[0])
            self.team_list.insert(row_index, '%4d  %s' % (tid, m.team_pc_name(row)))
            self.team_list.selection_set(row_index)
            self.status.set('Takım uygulandı (kaydetmeyi unutma).')
        except Exception as ex:
            messagebox.showerror('Hata', str(ex))

    def fill_players(self):
        if not self.model: return
        sel = self.team_filter.current()
        self.player_list.delete(0, 'end'); self.player_rows = []
        m = self.model
        if sel <= 0:
            rows = [(m.pc['players'].get(i, 'playerid'), i) for i in range(m.pc['players'].cnt)]
        else:
            tid = self.team_rows[sel - 1][0]
            rows = [(m.pc['players'].get(i, 'playerid'), i) for i in m.players_of_team(tid)]
        for pid, i in rows:
            self.player_list.insert('end', '%6d  %s' % (pid, m.player_name(pid)))
            self.player_rows.append((pid, i))

    def on_player(self, _=None):
        sel = self.player_list.curselection()
        if not sel: return
        pid, row = self.player_rows[sel[0]]
        m = self.model; p = m.pc['players']
        for w in self.pform.winfo_children(): w.destroy()
        self.pvars = {}; r = 0
        ttk.Label(self.pform, text='playerid: %d' % pid, font=('', 9, 'bold')).grid(row=r, column=0, columnspan=2, sticky='w'); r += 1
        for lbl, key in (('Ad (firstname)', 'firstnameid'), ('Soyad (lastname)', 'lastnameid'), ('Ortak ad (common)', 'commonnameid')):
            nid = p.get(row, key)
            v = tk.StringVar(value=m.pc_text(nid)); self.pvars['T:' + key] = (v, nid)
            ttk.Label(self.pform, text=lbl).grid(row=r, column=0, sticky='w', padx=4, pady=2)
            ttk.Entry(self.pform, textvariable=v, width=36).grid(row=r, column=1, sticky='w', padx=4); r += 1
        for f in PLAYER_NUM:
            if f not in p.fmap: continue
            v = tk.StringVar(value=str(p.get(row, f))); self.pvars[f] = (v, row)
            ttk.Label(self.pform, text=f).grid(row=r, column=0, sticky='w', padx=4, pady=1)
            ttk.Entry(self.pform, textvariable=v, width=36).grid(row=r, column=1, sticky='w', padx=4); r += 1
        self.player_current = (pid, row)
        ttk.Button(self.pform, text='Bu oyuncuyu uygula', command=self.apply_player).grid(row=r, column=0, columnspan=2, pady=8)
        ttk.Label(self.pform, text='Not: ad değişikliği bu isme bağlı TÜM oyuncuları etkiler.').grid(row=r+1, column=0, columnspan=2, sticky='w')

    def apply_player(self):
        m = self.model; pid, row = self.player_current
        try:
            p = m.pc['players']
            for k, (v, ref) in self.pvars.items():
                if k.startswith('T:'):
                    txt = v.get().strip()
                    if txt and txt != m.pc_text(ref): m.set_pc_text(ref, txt)
                else:
                    p.set(row, k, int(v.get()))
            self.status.set('Oyuncu uygulandı (kaydetmeyi unutma).')
            self.fill_players()
        except Exception as ex:
            messagebox.showerror('Hata', str(ex))

    def save(self):
        if not self.model: return
        try:
            # acik olan takim/oyuncu formundaki son degisiklikleri de uygula
            if hasattr(self, 'team_row_current') and self.team_vars: self.apply_team()
            if hasattr(self, 'player_current') and self.pvars: self.apply_player()
            self.model.save()
            self.status.set('Kaydedildi. Eski dosyalar .bak olarak duruyor.')
        except Exception as ex:
            messagebox.showerror('Kaydetme hatası', str(ex))


if __name__ == '__main__':
    pc = sys.argv[1] if len(sys.argv) > 1 else os.path.join(CALISMA, 'fifa_street_db.db')
    lc = sys.argv[2] if len(sys.argv) > 2 else os.path.join(CALISMA, 'eng_us.db')
    App(pc, None, lc, None).mainloop()
