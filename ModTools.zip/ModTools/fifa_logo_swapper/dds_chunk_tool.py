#!/usr/bin/env python3
"""
FIFA Street (Xbox 360) DDS Chunklzx Aracı
UI/Menü takım logoları (.dds) için dışa/içe aktarma aracı.
chunklzx sıkıştırmasını çözer/sıkıştırır ve Xbox 360 Big-Endian bayt kaymasını (DXT word swap) düzeltir.

Kullanım:
  python dds_chunk_tool.py export <girdi.dds | klasör> [çikti_klasörü]
  python dds_chunk_tool.py import <orijinal.dds> <modlu_pc.dds> [çikti.dds]
  python dds_chunk_tool.py batch_import <orijinal_klasör> <modlu_klasör> <çikti_klasörü>
"""

import sys, os, struct

try:
    import chunklzx
    import chunklzx_enc
except ImportError:
    print("HATA: chunklzx.py ve chunklzx_enc.py aynı klasörde bulunmalı!")
    sys.exit(1)

def get_header_size(data):
    """DDS dosyasının başlık (header) uzunluğunu belirler."""
    if len(data) < 128 or not data.startswith(b'DDS '):
        return 0
    # DX10 header kontrolü (varsa başlık 148 bayttır, yoksa 128)
    if data[84:88] == b'DX10':
        return 148
    return 128

def swap16(b):
    """16-bit word swap (Big-Endian <-> Little-Endian dönüşümü DXT/16-bit için)."""
    a = bytearray(len(b))
    end = len(b) - (len(b) % 2)
    a[0:end:2] = b[1:end:2]
    a[1:end:2] = b[0:end:2]
    if len(b) % 2 != 0:
        a[-1] = b[-1]
    return bytes(a)

def swap32(b):
    """32-bit word swap (Big-Endian <-> Little-Endian dönüşümü 32-bit ARGB8 için)."""
    a = bytearray(len(b))
    end = len(b) - (len(b) % 4)
    a[0:end:4] = b[3:end:4]
    a[1:end:4] = b[2:end:4]
    a[2:end:4] = b[1:end:4]
    a[3:end:4] = b[0:end:4]
    if len(b) % 4 != 0:
        a[end:] = b[end:]
    return bytes(a)

def get_swap_method(header):
    """DDS başlığını inceleyip formatına göre en uygun swap metodunu seçer."""
    if len(header) < 128:
        return swap16
    fourcc = header[84:88]
    rgb_bit_count = struct.unpack('<I', header[88:92])[0]
    
    # Sıkıştırmasız raw ARGB8 formatı için 32-bit, DXT1/3/5 için standart 16-bit swap gerekir.
    if fourcc == b'\x00\x00\x00\x00':
        if rgb_bit_count == 32:
            return swap32
    return swap16

def export_dds(in_path, out_path):
    with open(in_path, 'rb') as f:
        data = f.read()
    
    is_chunklzx = data[:8] == b'chunklzx'
    if is_chunklzx:
        try:
            dec_data = chunklzx.decompress(data)
        except Exception as e:
            print(f"HATA ({in_path}): chunklzx açılamadı -> {e}")
            return False
    else:
        dec_data = data
        
    hdr_size = get_header_size(dec_data)
    if hdr_size == 0:
        print(f"ATLANDI: {in_path} (Geçerli DDS başlığı bulunamadı)")
        return False
        
    header = dec_data[:hdr_size]
    payload = dec_data[hdr_size:]
    
    swap_func = get_swap_method(header)
    pc_payload = swap_func(payload)
    
    with open(out_path, 'wb') as f:
        f.write(header)
        f.write(pc_payload)
        
    print(f"DIŞA AKTARILDI: {out_path} ({'DXT/16-bit' if swap_func == swap16 else '32-bit ARGB'} swap uygulandı)")
    return True

def import_dds(orig_path, mod_path, out_path):
    with open(orig_path, 'rb') as f:
        orig_data = f.read()
        
    is_chunklzx = orig_data[:8] == b'chunklzx'
    if is_chunklzx:
        orig_hdr = orig_data[:0x28]  # Sıkıştırma ayarlarını korumak için orijinal başlığı alıyoruz
    
    with open(mod_path, 'rb') as f:
        mod_data = f.read()
        
    hdr_size = get_header_size(mod_data)
    if hdr_size == 0:
        print(f"HATA: Modlu dosya geçerli bir PC DDS değil ({mod_path}).")
        return False
        
    header = mod_data[:hdr_size]
    payload = mod_data[hdr_size:]
    
    swap_func = get_swap_method(header)
    x360_payload = swap_func(payload)
    
    x360_dds = header + x360_payload
    
    if is_chunklzx:
        try:
            out_data = chunklzx_enc.compress(x360_dds, orig_hdr)
        except Exception as e:
            print(f"HATA ({mod_path}): chunklzx sıkıştırma başarısız -> {e}")
            return False
    else:
        out_data = x360_dds
    
    with open(out_path, 'wb') as f:
        f.write(out_data)
        
    print(f"İÇE AKTARILDI: {out_path} ({'chunklzx ile sıkıştırıldı' if is_chunklzx else 'sıkıştırma olmadan kaydedildi'})")
    return True

def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
        
    cmd = sys.argv[1].lower()
    
    if cmd == "export":
        if len(sys.argv) < 3:
            print("HATA: Girdi dosyası veya klasörü belirtilmedi.")
            sys.exit(1)
            
        in_path = sys.argv[2]
        out_dir = sys.argv[3] if len(sys.argv) > 3 else "export_out"
        os.makedirs(out_dir, exist_ok=True)
        
        if os.path.isdir(in_path):
            for filename in os.listdir(in_path):
                if filename.lower().endswith('.dds'):
                    out_path = os.path.join(out_dir, filename.replace('.dds', '_pc.dds'))
                    export_dds(os.path.join(in_path, filename), out_path)
        else:
            out_path = os.path.join(out_dir, os.path.basename(in_path).replace('.dds', '_pc.dds'))
            export_dds(in_path, out_path)
            
    elif cmd == "import":
        if len(sys.argv) < 4:
            print("HATA: Eksik parametre! Kullanım: import <orijinal.dds> <modlu_pc.dds> [çikti.dds]")
            sys.exit(1)
        orig_path = sys.argv[2]
        mod_path = sys.argv[3]
        out_path = sys.argv[4] if len(sys.argv) > 4 else os.path.join("import_out", os.path.basename(orig_path))
        os.makedirs(os.path.dirname(os.path.abspath(out_path)), exist_ok=True)
        
        import_dds(orig_path, mod_path, out_path)
        
    elif cmd == "batch_import":
        if len(sys.argv) < 5:
            print("HATA: Eksik parametre! Kullanım: batch_import <orijinal_klasör> <modlu_klasör> <çikti_klasörü>")
            sys.exit(1)
        orig_dir = sys.argv[2]
        mod_dir = sys.argv[3]
        out_dir = sys.argv[4]
        
        os.makedirs(out_dir, exist_ok=True)
        for filename in os.listdir(mod_dir):
            if filename.lower().endswith('.dds'):
                base_name = filename.replace('_pc.dds', '.dds')
                orig_path = os.path.join(orig_dir, base_name)
                
                if not os.path.exists(orig_path):
                    orig_path = os.path.join(orig_dir, filename)
                    
                if os.path.exists(orig_path):
                    out_path = os.path.join(out_dir, base_name)
                    import_dds(orig_path, os.path.join(mod_dir, filename), out_path)
                else:
                    print(f"UYARI: Orijinal dosya bulunamadı, atlandı ({base_name})")
    else:
        print(f"Bilinmeyen komut: {cmd}")
        print(__doc__)

if __name__ == '__main__':
    main()