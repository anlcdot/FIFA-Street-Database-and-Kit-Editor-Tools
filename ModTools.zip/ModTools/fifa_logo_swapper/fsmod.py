#!/usr/bin/env python3
"""FIFA Street UI & Logo (DDS) Modlama Arayüzü - Gelişmiş Sürüm"""
import os, sys, json, threading, traceback, struct, base64, zlib, shutil, stat
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import fstool, chunklzx, chunklzx_enc, rx3view

HERE = os.path.dirname(os.path.abspath(__file__))
CFG = os.path.join(HERE, 'fsmod_dds_ayar.json')
WORK_DIR = os.path.join(HERE, 'calisma_logolar')

# --- KATEGORİLER DÜZELTİLDİ ---
CATEGORIES = {
    "Tüm Dosyalar (*.dds)": ".dds",
    "Tüm Takım Logoları": "crest/",
    "Takım Logoları (Küçük)": "licensed_small/",
    "Takım Logoları (Orta)": "licensed_medium/",
    "Takım Logoları (Büyük)": "licensed_large/",
    "Formalar (Kits)": "imgassets/kits/",
}

# ---- BAYT DÖNÜŞÜM (SWAP) FONKSİYONLARI ----
def swap16(b):
    a = bytearray(len(b))
    end = len(b) - (len(b) % 2)
    a[0:end:2] = b[1:end:2]; a[1:end:2] = b[0:end:2]
    if len(b) % 2 != 0: a[-1] = b[-1]
    return bytes(a)

def swap32(b):
    a = bytearray(len(b))
    end = len(b) - (len(b) % 4)
    a[0:end:4] = b[3:end:4]; a[1:end:4] = b[2:end:4]
    a[2:end:4] = b[1:end:4]; a[3:end:4] = b[0:end:4]
    if len(b) % 4 != 0: a[end:] = b[end:]
    return bytes(a)

def get_swap_method(header):
    if len(header) < 128: return swap16
    if header[84:88] == b'\x00\x00\x00\x00':
        if struct.unpack('<I', header[88:92])[0] == 32: return swap32
    return swap16
# -------------------------------------------

# ---- CHUNK SIKIŞTIRMA / AÇMA FONKSİYONLARI ----
def ea_decompress(data):
    if data.startswith(b'chunklzx'):
        return chunklzx.decompress(data)
    elif data.startswith(b'chunkzip'):
        ver, total, csize, nch, hsz = struct.unpack('>5I', data[8:28])
        pos = 0x28
        res = bytearray()
        for i in range(nch):
            while pos + 8 <= len(data) and data[pos:pos+8] == b'\x00'*8: pos += 8
            if pos + 8 > len(data): break
            sz, flag = struct.unpack('>II', data[pos:pos+8])
            payload = data[pos+8 : pos+8+sz]
            try: dec = zlib.decompress(payload)
            except zlib.error: dec = zlib.decompress(payload, -15)
            res += dec
            pos = (pos + 8 + sz + 7) & ~7
        return bytes(res)
    return data 

def ea_compress(data, orig_raw):
    if orig_raw.startswith(b'chunklzx'):
        return chunklzx_enc.compress(data, orig_raw[:0x28])
    elif orig_raw.startswith(b'chunkzip'):
        csize = 262144
        total = len(data)
        nch = (total + csize - 1) // csize
        out = bytearray(orig_raw[:0x28])
        struct.pack_into('>II', out, 0x0C, total, csize)
        struct.pack_into('>I', out, 0x14, nch)
        
        pos = 0x28
        while pos+8 <= len(orig_raw) and orig_raw[pos:pos+8] == b'\x00'*8: pos += 8
        flag = struct.unpack('>II', orig_raw[pos:pos+8])[1] if pos+8 <= len(orig_raw) else 3
        
        for i in range(nch):
            chunk = data[i*csize : (i+1)*csize]
            comp = zlib.compress(chunk, level=9)
            while (len(out) + 8) % 16 != 0: out.append(0)
            out += struct.pack('>II', len(comp), flag) + comp
        while len(out) % 16 != 0: out.append(0)
        return bytes(out)
    return data
# ------------------------------------------------------------

class App(tk.Tk):
    def __init__(s):
        super().__init__(); s.title('FIFA Street DDS Logo Aracı (Akıllı Aramalı)')
        s.geometry('1100x680')
        try: s.cfg = json.load(open(CFG))
        except Exception: s.cfg = {}
        s.big = s.cfg.get('big', ''); s.ents = []; s.cur = None; s.photo = None
        
        # ÜST PANEL
        top = ttk.Frame(s); top.pack(fill='x', padx=6, pady=6)
        ttk.Button(top, text='data1.big Seç...', command=s.pick_big).pack(side='left')
        s.lbl = ttk.Label(top, text=s.big or '(seçilmedi)'); s.lbl.pack(side='left', padx=8)
        
        ttk.Label(top, text='Kategori:').pack(side='left', padx=(20, 2))
        s.cat_var = tk.StringVar(value="Tüm Dosyalar (*.dds)")
        s.cat_combo = ttk.Combobox(top, textvariable=s.cat_var, values=list(CATEGORIES.keys()), state='readonly', width=22)
        s.cat_combo.pack(side='left'); s.cat_combo.bind('<<ComboboxSelected>>', s.on_category_change)
        
        ttk.Label(top, text='Akıllı Ara:').pack(side='left', padx=(12, 2))
        s.q = tk.StringVar(value=s.cfg.get('filter', CATEGORIES["Tüm Dosyalar (*.dds)"]))
        e = ttk.Entry(top, textvariable=s.q, width=30); e.pack(side='left')
        
        # Canlı arama için Trace
        s.q.trace_add('write', s.refill)
        
        s.cnt = ttk.Label(top, text=''); s.cnt.pack(side='left', padx=8)
        
        # ORTA PANEL
        mid = ttk.PanedWindow(s, orient='horizontal'); mid.pack(fill='both', expand=True, padx=6)
        lf = ttk.Frame(mid); mid.add(lf, weight=2)
        s.lb = tk.Listbox(lf, exportselection=False, font=("Consolas", 9)); sb = ttk.Scrollbar(lf, command=s.lb.yview)
        s.lb.config(yscrollcommand=sb.set); s.lb.pack(side='left', fill='both', expand=True); sb.pack(side='right', fill='y')
        s.lb.bind('<<ListboxSelect>>', s.on_sel)
        
        rf = ttk.Frame(mid); mid.add(rf, weight=3)
        s.img = ttk.Label(rf, text='Soldan bir dosya seçin.', anchor='center')
        s.img.pack(fill='both', expand=True, pady=4)
        
        # ALT PANEL
        s.do_swap_var = tk.BooleanVar(value=False) 
        
        bt_top = ttk.Frame(s); bt_top.pack(fill='x', padx=6, pady=(4, 0))
        cb = ttk.Checkbutton(bt_top, text='Görüntü bozuksa (neon renkliyse) işaretle (Xbox 360 Byte Swap)', variable=s.do_swap_var, command=s.on_sel)
        cb.pack(side='left', padx=2)

        bt = ttk.Frame(s); bt.pack(fill='x', padx=6, pady=(2, 6))
        ttk.Button(bt, text='1) Seçili Dosyayı Klasöre Çıkar', command=s.do_extract).pack(side='left')
        ttk.Button(bt, text='Çıktı Klasörünü Aç', command=s.open_dir).pack(side='left', padx=4)
        
        b2 = ttk.Button(bt, text='2) Yeni Modlu DDS Seç ve Üzerine Yaz (Göm)', command=s.do_import, style="Accent.TButton")
        b2.pack(side='right', padx=2)
        
        s.log = tk.Text(s, height=6, bg="#f9f9f9", font=("Consolas", 9)); s.log.pack(fill='x', padx=6, pady=(0, 6))
        if s.big and os.path.exists(s.big): s.load_index()

    def say(s, m): s.after(0, lambda: (s.log.insert('end', m + '\n'), s.log.see('end')))
    def save_cfg(s):
        s.cfg.update(big=s.big, filter=s.q.get())
        try: json.dump(s.cfg, open(CFG, 'w'))
        except Exception: pass

    def on_category_change(s, _=None):
        cat = s.cat_var.get()
        if cat in CATEGORIES:
            s.q.set(CATEGORIES[cat])

    def pick_big(s):
        p = filedialog.askopenfilename(title='data1.big seç', filetypes=[('BIG', '*.big'), ('Hepsi', '*.*')])
        if not p: return
        s.big = p; s.lbl.config(text=p); s.save_cfg()
        
        if os.path.exists(WORK_DIR):
            try:
                def remove_readonly(func, path, excinfo):
                    os.chmod(path, stat.S_IWRITE); func(path)
                shutil.rmtree(WORK_DIR, onerror=remove_readonly)
                s.say("Eski çalışma klasörü temizlendi.")
            except Exception as ex:
                s.say(f"Çalışma klasörü temizlenemedi: {ex}")
                
        s.load_index()

    def load_index(s):
        s.say('BIG indeksi okunuyor...')
        def w():
            try:
                with open(s.big, 'rb') as f: _, ents = fstool.read_index(f)
                s.ents = ents; s.after(0, s.refill); s.say(f'{len(ents)} dosya bulundu.')
            except Exception as ex: s.say('HATA: %s' % ex)
        threading.Thread(target=w, daemon=True).start()

    def refill(s, *args):
        q_text = s.q.get().lower().replace('\\', '/')
        s.save_cfg()
        
        keywords = q_text.split()
        s.shown = []
        
        for e in s.ents:
            name_lower = e['name'].lower()
            if name_lower.endswith('.dds'):
                if all(k in name_lower for k in keywords):
                    s.shown.append(e)
                    
        s.lb.delete(0, 'end')
        for e in s.shown: s.lb.insert('end', e['name'])
        s.cnt.config(text='%d .dds' % len(s.shown))

    def read_raw(s, e):
        with open(s.big, 'rb') as f:
            f.seek(e['off'])
            return f.read(e['size'])

    def on_sel(s, _=None):
        i = s.lb.curselection()
        if not i: return
        e = s.shown[i[0]]; s.cur = e
        s.img.config(image='', text='Yükleniyor...')
        
        def w():
            try:
                raw = s.read_raw(e)
                ctype = "chunklzx" if raw.startswith(b'chunklzx') else "chunkzip" if raw.startswith(b'chunkzip') else "Yok (Raw)"
                dec = ea_decompress(raw)
                idx = dec.find(b'DDS ')
                
                if idx == -1:
                    s.after(0, lambda: s.img.config(text=f"EA Metadata - Geçerli DDS başlığı yok.\nSıkıştırma Tipi: {ctype}"))
                    return
                
                hdr = dec[idx:idx+128]
                h, w_px = struct.unpack('<II', hdr[12:20])
                fourcc = hdr[84:88]
                fmt = 0 if fourcc == b'DXT1' else 1 if fourcc == b'DXT3' else 2 if fourcc == b'DXT5' else -1
                
                if fmt != -1:
                    hdr_size = 148 if fourcc == b'DX10' else 128
                    payload = dec[idx+hdr_size:]
                    
                    if s.do_swap_var.get(): pc_payload = get_swap_method(hdr)(payload)
                    else: pc_payload = payload
                        
                    rows = rx3view.decode_dxt(pc_payload, w_px, h, fmt)
                    
                    f = 1
                    while max(w_px, h)//f > 256: f *= 2
                    if f > 1:
                        rows = [bytearray(b''.join(bytes(r[x*3:x*3+3]) for x in range(0, w_px, f))) for r in rows[::f]]
                        w_px, h = (w_px+f-1)//f, (h+f-1)//f
                    
                    png_data = rx3view.png_bytes(rows, w_px, h)
                    s.photo = tk.PhotoImage(data=base64.b64encode(png_data).decode())
                    s.after(0, lambda: s.img.config(image=s.photo, text=f'Sıkıştırma: {ctype}'))
                else:
                    s.after(0, lambda: s.img.config(text=f"Sıkıştırma: {ctype}\nÖnizleme DXT1/3/5 destekler (Bu dosya formatı: {fourcc.decode('ascii', errors='ignore')})"))
            except Exception as ex:
                s.after(0, lambda: s.img.config(text=f'Önizleme Hatası: {ex}'))
        threading.Thread(target=w, daemon=True).start()

    def do_extract(s):
        if not s.cur: return messagebox.showinfo('', 'Önce soldan bir dosya seçin.')
        e = s.cur
        def w():
            try:
                raw = s.read_raw(e)
                dec = ea_decompress(raw)
                idx = dec.find(b'DDS ')
                
                if idx == -1:
                    out_data = dec
                    s.say("UYARI: DDS yazısı bulunamadı, dosya ham olarak dışarı aktarılıyor.")
                else:
                    hdr_size = 148 if dec[idx+84:idx+88] == b'DX10' else 128
                    header = dec[idx:idx+hdr_size]
                    payload = dec[idx+hdr_size:]
                    
                    if s.do_swap_var.get(): out_data = header + get_swap_method(header)(payload) 
                    else: out_data = header + payload
                
                os.makedirs(WORK_DIR, exist_ok=True)
                out_path = os.path.join(WORK_DIR, os.path.basename(e['name']))
                with open(out_path, 'wb') as f: f.write(out_data)
                s.say(f"ÇIKARILDI: {os.path.basename(e['name'])}\n(Photoshop/Paint.NET ile düzenleyebilirsiniz.)")
            except Exception as ex: s.say('HATA: ' + str(ex))
        threading.Thread(target=w, daemon=True).start()

    def open_dir(s):
        os.makedirs(WORK_DIR, exist_ok=True)
        if os.name == 'nt': os.startfile(WORK_DIR)

    def do_import(s):
        if not s.cur: return messagebox.showinfo('', 'Önce listeden HANGİ DOSYANIN üzerine yazacağınızı seçin.')
        e = s.cur
        mod_path = filedialog.askopenfilename(title='Düzenlediğiniz YENİ .dds dosyasını seçin', filetypes=[('DDS', '*.dds'), ('Hepsi', '*.*')])
        if not mod_path: return
        
        if not messagebox.askyesno('Onay', f"{e['name']} dosyası BIG içine GÖMÜLECEK.\nYedek (.bak) otomatik alınır. Emin misiniz?"): return
        
        def w():
            try:
                mod_data = open(mod_path, 'rb').read()
                mod_idx = mod_data.find(b'DDS ')
                if mod_idx == -1: raise ValueError("Seçtiğiniz dosya geçerli bir DDS değil!")
                
                hdr_size = 148 if mod_data[mod_idx+84:mod_idx+88] == b'DX10' else 128
                mod_hdr = mod_data[mod_idx:mod_idx+hdr_size]
                payload = mod_data[mod_idx+hdr_size:]
                
                if s.do_swap_var.get(): x360_payload = get_swap_method(mod_hdr)(payload)
                else: x360_payload = payload
                    
                x360_dds = mod_hdr + x360_payload
                
                raw = s.read_raw(e)
                dec = ea_decompress(raw)
                orig_idx = dec.find(b'DDS ')
                prefix = dec[:orig_idx] if orig_idx > 0 else b''
                
                final_uncomp = prefix + x360_dds
                
                s.say("Dosya orijinal formatında (chunkzip/chunklzx) paketleniyor...")
                final_data = ea_compress(final_uncomp, raw)
                
                tmp = os.path.join(WORK_DIR, '_tmp.dds')
                open(tmp, 'wb').write(final_data)
                
                s.say("data1.big üzerine yazılıyor, yedek alınıyor...")
                fstool.import_files(s.big, [(e['name'], tmp)], s.say, raw=True)
                
                s.load_index()
                s.say("İŞLEM TAMAM! Oyunda test edebilirsiniz.")
                
            except Exception as ex: s.say('GÖMME HATASI: ' + traceback.format_exc())
        threading.Thread(target=w, daemon=True).start()

if __name__ == '__main__':
    App().mainloop()