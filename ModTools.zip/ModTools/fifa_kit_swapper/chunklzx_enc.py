import struct, heapq, sys
from collections import defaultdict
FR=32768; WB=17; SLOTS=34; NMAIN=256+SLOTS*8
EXTRA=[0 if i<4 else min(17,(i>>1)-1) for i in range(SLOTS)]
BASE=[0]*SLOTS
for i in range(1,SLOTS): BASE[i]=BASE[i-1]+(1<<EXTRA[i-1])
MAXOFF=(1<<WB)-3

class BW:
    def __init__(s): s.o=bytearray(); s.a=0; s.n=0
    def w(s,v,k):
        if k==0: return
        s.a=(s.a<<k)|v; s.n+=k
        while s.n>=16:
            x=(s.a>>(s.n-16))&0xFFFF; s.o+=bytes((x&255,x>>8)); s.n-=16
        s.a&=(1<<s.n)-1
    def flush(s):
        if s.n: x=(s.a<<(16-s.n))&0xFFFF; s.o+=bytes((x&255,x>>8)); s.a=0; s.n=0
        return bytes(s.o)

def huff_lens(freqs, limit):
    n=len(freqs); f=list(freqs)
    syms=[i for i in range(n) if f[i]]
    if not syms: return [0]*n
    if len(syms)==1:
        l=[0]*n; l[syms[0]]=1; l[1 if syms[0]==0 else 0]=1; return l
    while True:
        h=[(f[i],i,None) for i in syms]; heapq.heapify(h); cnt=n
        while len(h)>1:
            a=heapq.heappop(h); b=heapq.heappop(h); cnt+=1
            heapq.heappush(h,(a[0]+b[0],cnt,(a,b)))
        l=[0]*n; st=[(h[0],0)]
        while st:
            nd,d=st.pop()
            if nd[2] is None: l[nd[1]]=d
            else: st.append((nd[2][0],d+1)); st.append((nd[2][1],d+1))
        if max(l)<=limit: return l
        f=[max(1,x>>1) if x else 0 for x in f]

def codes(lens):
    mx=max(lens) if lens else 0; res={}; code=0
    for l in range(1,mx+1):
        syms=[i for i,x in enumerate(lens) if x==l]
        for s in syms: res[s]=(code,l); code+=1
        code<<=1
    return res

def write_tree(bw, lens, lo, hi):
    seq=[]; x=lo
    while x<hi:
        if lens[x]==0:
            r=1
            while x+r<hi and lens[x+r]==0: r+=1
            if r>=4:
                t=min(r,51) if r>=20 else min(r,19)
                seq.append((18,t-20,5) if t>=20 else (17,t-4,4)); x+=t; continue
        seq.append(((PREV[x]-lens[x])%17,0,0)); x+=1
    fr=[0]*20
    for s,_,_ in seq: fr[s]+=1
    pl=huff_lens(fr,15)
    for v in pl: bw.w(v,4)
    pc=codes(pl)
    for s,e,k in seq:
        c,l=pc[s]; bw.w(c,l); bw.w(e,k)

def tokenize(data):
    n=len(data); R=[1,1,1]; toks=[]; head=defaultdict(list)
    i=0; fe=0
    def ins(p):
        if p+3<=n: head[data[p:p+3]].append(p)
    while i<n:
        fe=(i//FR+1)*FR; lim=min(257,min(fe,n)-i)
        best=(0,0,-1)  # len, off, rslot
        for rs in range(3):
            o=R[rs]
            if o<=i:
                l=0
                while l<lim and data[i+l]==data[i+l-o]: l+=1
                if l>=2 and l>best[0]: best=(l,o,rs)
        if lim>=3:
            c=head.get(data[i:i+3])
            if c:
                for p in reversed(c[-24:]):
                    o=i-p
                    if o>MAXOFF: break
                    l=3
                    while l<lim and data[p+l]==data[i+l]: l+=1
                    if l>best[0]+ (0 if best[2]==-1 else 0) and not (best[2]>=0 and l<=best[0]+1): best=(l,o,-1)
                    if l==lim: break
        l,o,rs=best
        if l<3 and rs==-1 or l<2:
            toks.append((0,data[i],0,0)); ins(i); i+=1; continue
        if rs>=0:
            if rs==1: R[1]=R[0]; R[0]=o
            elif rs==2: R[2]=R[0]; R[0]=o
            slot=rs
        else:
            fm=o+2; slot=max(s for s in range(3,SLOTS) if BASE[s]<=fm)
            R[2]=R[1]; R[1]=R[0]; R[0]=o
        toks.append((1,l,slot,o))
        for k in range(l): ins(i+k)
        i+=l
    return toks

def encode_chunk(data):
    n=len(data); toks=tokenize(data)
    mf=[0]*NMAIN; lf=[0]*249; syms=[]
    for t in toks:
        if t[0]==0: mf[t[1]]+=1; continue
        _,l,slot,o=t; ml=l-2
        mf[256+(slot<<3)+min(ml,7)]+=1
        if ml>=7: lf[ml-7]+=1
    ml_=huff_lens(mf,16); ll_=huff_lens(lf,16)
    global PREV
    mc=codes(ml_); lc=codes(ll_)
    # split tokens per frame
    frames=[]; pos=0; cur=[]; 
    for t in toks:
        cur.append(t); pos+= 1 if t[0]==0 else t[1]
        if pos%FR==0 or pos==n: frames.append(cur); cur=[]
    out=bytearray()
    for fi,ft in enumerate(frames):
        bw=BW()
        if fi==0:
            bw.w(0,1); bw.w(1,3); bw.w(n>>8,16); bw.w(n&255,8)
            PREV=[0]*NMAIN; write_tree(bw,ml_,0,256)
            PREV=[0]*NMAIN
            write_tree(bw,ml_,256,NMAIN)
            PREV=[0]*249; write_tree(bw,ll_,0,249)
        for t in ft:
            if t[0]==0: c,l=mc[t[1]]; bw.w(c,l)
            else:
                _,L,slot,o=t; ml=L-2
                c,l=mc[256+(slot<<3)+min(ml,7)]; bw.w(c,l)
                if ml>=7: c,l=lc[ml-7]; bw.w(c,l)
                if slot>=3 and EXTRA[slot]: bw.w(o+2-BASE[slot],EXTRA[slot])
        b=bw.flush(); usz=sum(1 if t[0]==0 else t[1] for t in ft)
        if usz==FR: out+=struct.pack('>H',len(b))
        else: out+=b'\xff'+struct.pack('>HH',usz,len(b))
        out+=b
    return bytes(out)

def compress(d, hdr):
    # hdr: orijinal header 0x28 bayt (sablon). Boyutlar guncellenir.
    csize=262144; total=len(d)
    nch=(total+csize-1)//csize
    out=bytearray(hdr[:0x28]); struct.pack_into('>II',out,0x0C,total,csize); struct.pack_into('>I',out,0x14,nch)
    for i in range(nch):
        p=encode_chunk(d[i*csize:(i+1)*csize])
        while (len(out)+8)%16: out.append(0)
        out+=struct.pack('>II',len(p),3)+p
    while len(out)%16: out.append(0)
    return bytes(out)
if __name__=='__main__':
    import os; sys.path.insert(0,os.path.dirname(os.path.abspath(__file__))); import chunklzx
    orig=open(sys.argv[1],'rb').read(); dec=chunklzx.decompress(orig)
    c=compress(dec,orig); open(sys.argv[2],'wb').write(c)
    print(len(orig),'->',len(c)); print('roundtrip',chunklzx.decompress(c)==dec)
