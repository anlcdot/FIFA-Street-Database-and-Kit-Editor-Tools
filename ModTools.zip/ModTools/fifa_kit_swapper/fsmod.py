#!/usr/bin/env python3
"""FIFA Street forma modlama arayuzu (Xbox360 BIG4 + chunklzx + RX3).  Calistir: python fsmod.py"""
import os, sys, json, hashlib, base64, threading, subprocess, traceback, shutil, stat
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import fstool, chunklzx, rx3view, rx3png

HERE = os.path.dirname(os.path.abspath(__file__))
CFG = os.path.join(HERE, 'fsmod_ayar.json')
WORK = os.path.join(HERE, 'calisma')
ORIG = os.path.join(WORK, '_orijinal_hash.json')

CATEGORIES = {
    "Formalar (Kit)": "sceneassets/kit/",
    "Ayakkabilar (Shoe)": "sceneassets/shoe/",
    "Toplar (Ball)": "sceneassets/ball/",
    "Yuzler/Saclar (Heads)": "sceneassets/",
    "Tum Dosyalar (*.*)": "",
}

def md5(p): return hashlib.md5(open(p, 'rb').read()).hexdigest()

class App(tk.Tk):
    def __init__(s):
        super().__init__(); s.title('FIFA Street Forma Araci'); s.geometry('1150x700')
        try: s.cfg = json.load(open(CFG))
        except Exception: s.cfg = {}
        s.big = s.cfg.get('big', ''); s.ents = []; s.cur = None; s.cache = {}; s.texs = []; s.photo = None
        try: s.orig = json.load(open(ORIG))
        except Exception: s.orig = {}
        top = ttk.Frame(s); top.pack(fill='x', padx=6, pady=6)
        ttk.Button(top, text='Big dosyasi sec...', command=s.pick_big).pack(side='left')
        s.lbl = ttk.Label(top, text=s.big or '(secilmedi)'); s.lbl.pack(side='left', padx=8)
        ttk.Label(top, text='Kategori:').pack(side='left', padx=(20, 2))
        s.cat_var = tk.StringVar(value="Formalar (Kit)")
        s.cat_combo = ttk.Combobox(top, textvariable=s.cat_var, values=list(CATEGORIES.keys()), state='readonly', width=22)
        s.cat_combo.pack(side='left'); s.cat_combo.bind('<<ComboboxSelected>>', s.on_category_change)
        ttk.Label(top, text='Ara:').pack(side='left', padx=(12, 2))
        s.q = tk.StringVar(value=s.cfg.get('filter', 'sceneassets/kit/'))
        e = ttk.Entry(top, textvariable=s.q, width=30); e.pack(side='left'); e.bind('<Return>', lambda _: s.refill())
        ttk.Button(top, text='Filtrele', command=s.refill).pack(side='left', padx=4)
        s.cnt = ttk.Label(top, text=''); s.cnt.pack(side='left', padx=8)
        mid = ttk.PanedWindow(s, orient='horizontal'); mid.pack(fill='both', expand=True, padx=6)
        lf = ttk.Frame(mid); mid.add(lf, weight=2)
        s.lb = tk.Listbox(lf, exportselection=False); sb = ttk.Scrollbar(lf, command=s.lb.yview)
        s.lb.config(yscrollcommand=sb.set); s.lb.pack(side='left', fill='both', expand=True); sb.pack(side='right', fill='y')
        s.lb.bind('<<ListboxSelect>>', s.on_sel)
        rf = ttk.Frame(mid); mid.add(rf, weight=3)
        s.tlb = tk.Listbox(rf, height=6, exportselection=False); s.tlb.pack(fill='x'); s.tlb.bind('<<ListboxSelect>>', s.on_tex)
        s.img = ttk.Label(rf, text='Soldan bir dosya sec', anchor='center'); s.img.pack(fill='both', expand=True, pady=4)
        bt = ttk.Frame(s); bt.pack(fill='x', padx=6, pady=(4, 0))
        bt2 = ttk.Frame(s); bt2.pack(fill='x', padx=6, pady=(2, 4))
        ttk.Button(bt, text='1) Rx3Tools icin cikar', command=s.do_extract).pack(side='left')
        ttk.Button(bt, text='Klasoru ac', command=s.open_dir).pack(side='left', padx=4)
        ttk.Button(bt, text='Rx3Tools.exe sec/ac', command=s.open_rx3tools).pack(side='left', padx=4)
        ttk.Button(bt, text="1b) Rx3Tools'tan cikan yeni RX3'u sec", command=s.do_replace).pack(side='left', padx=4)
        ttk.Button(bt, text="2) Degisenleri big'e yaz", command=s.do_import).pack(side='left', padx=(20, 0))
        ttk.Button(bt2, text='PNG cikar (rx3c)', command=s.do_png_export).pack(side='left', padx=4)
        ttk.Button(bt2, text='PNG klasorunden aktar (rx3c)', command=s.do_png_import).pack(side='left', padx=4)
        s.autoswap = tk.BooleanVar(value=False)
        ttk.Checkbutton(bt2, text='aktarimdan sonra doku sirasini cevir', variable=s.autoswap).pack(side='left', padx=(0, 10))
        ttk.Button(bt2, text='Secili dosyayi yedekten geri yukle', command=s.do_restore).pack(side='left', padx=4)
        ttk.Button(bt2, text='Doku sirasini cevir (secili dosya)', command=s.do_fixswap).pack(side='left', padx=4)
        ttk.Button(bt2, text='Test: ayni icerigi yeniden yaz', command=s.do_rewrite).pack(side='left', padx=4)
        ttk.Button(bt2, text="BH kontrol (sadece oku)", command=s.do_check).pack(side='left', padx=4)
        ttk.Button(bt2, text="BH'yi big ile esitle", command=s.do_sync).pack(side='left', padx=4)
        s.log = tk.Text(s, height=8); s.log.pack(fill='x', padx=6, pady=(0, 6))
        if s.big and os.path.exists(s.big): s.load_index()

    def say(s, m): s.after(0, lambda: (s.log.insert('end', m + '\n'), s.log.see('end')))
    def save_cfg(s):
        s.cfg.update(big=s.big, filter=s.q.get())
        try: json.dump(s.cfg, open(CFG, 'w'))
        except Exception: pass

    def on_category_change(s, _=None):
        cat = s.cat_var.get()
        if cat in CATEGORIES:
            s.q.set(CATEGORIES[cat]); s.refill()

    def pick_big(s):
        p = filedialog.askopenfilename(title='data3.big sec', filetypes=[('BIG', '*.big'), ('Hepsi', '*.*')])
        if not p: return
        s.big = p; s.lbl.config(text=p); s.save_cfg()
        if os.path.exists(WORK):
            try:
                def remove_readonly(func, path, excinfo):
                    os.chmod(path, stat.S_IWRITE); func(path)
                shutil.rmtree(WORK, onerror=remove_readonly)
            except Exception as ex:
                s.say("Calisma klasoru temizlenemedi: %s" % ex)
        s.cache.clear(); s.orig.clear()
        s.load_index()

    def load_index(s):
        s.say('indeks okunuyor...')
        def w():
            try:
                with open(s.big, 'rb') as f: _, ents = fstool.read_index(f)
                s.ents = ents; s.after(0, s.refill); s.say('%d dosya' % len(ents))
            except Exception as ex: s.say('HATA: %s' % ex)
        threading.Thread(target=w, daemon=True).start()

    def refill(s):
        q = s.q.get().lower().replace('\\', '/'); s.save_cfg()
        s.shown = [e for e in s.ents if q in e['name'].lower() and e['name'].lower().endswith('.rx3')]
        s.lb.delete(0, 'end')
        for e in s.shown: s.lb.insert('end', e['name'][len('data/sceneassets/'):] if e['name'].startswith('data/sceneassets/') else e['name'])
        s.cnt.config(text='%d .rx3' % len(s.shown))

    def read_rx3(s, e):
        if e['name'] in s.cache: return s.cache[e['name']]
        with open(s.big, 'rb') as f: f.seek(e['off']); d = f.read(e['size'])
        if d[:8] == b'chunklzx': d = chunklzx.decompress(d)
        if len(s.cache) > 8: s.cache.pop(next(iter(s.cache)))
        s.cache[e['name']] = d; return d

    def on_sel(s, _=None):
        i = s.lb.curselection()
        if not i: return
        e = s.shown[i[0]]; s.cur = e; s.img.config(image='', text='yukleniyor...'); s.tlb.delete(0, 'end')
        def w():
            try:
                d = s.read_rx3(e); texs = rx3view.parse(d)
                if s.cur is not e: return
                s.texs = texs; s.curdata = d
                def ui():
                    s.tlb.delete(0, 'end')
                    for t in texs: s.tlb.insert('end', '#%d  %s  %dx%d  mip:%d' % (t['index'], t['fmtname'], t['w'], t['h'], t['mips']))
                    if texs:
                        k = max(range(len(texs)), key=lambda j: texs[j]['w']*texs[j]['h']); s.tlb.selection_set(k); s.on_tex()
                s.after(0, ui)
            except Exception as ex:
                s.say('HATA (%s): %s' % (e['name'], ex))
                try: hd = s.read_rx3(e)[:4]
                except Exception: hd = b'?'
                s.after(0, lambda: s.img.config(text='acilamadi (dosya basi %r; RX3b olmali). Yedekten geri yuklemen gerekebilir.' % hd))
        threading.Thread(target=w, daemon=True).start()

    def on_tex(self, _=None):
        s = self; i = s.tlb.curselection()
        if not i: return
        t = s.texs[i[0]]; d = s.curdata; e = s.cur
        def w():
            try:
                png = rx3view.preview_png(d, t)
                def ui():
                    if s.cur is not e: return
                    if png is None: s.img.config(image='', text='(bu format icin onizleme yok: %s)' % t['fmtname'])
                    else:
                        s.photo = tk.PhotoImage(data=base64.b64encode(png).decode()); s.img.config(image=s.photo, text='')
                s.after(0, ui)
            except Exception as ex: s.say('onizleme HATA: %s' % ex)
        threading.Thread(target=w, daemon=True).start()

    def do_extract(s):
        if not s.cur: return messagebox.showinfo('', 'Once soldan bir dosya sec.')
        e = s.cur
        def w():
            try:
                d = s.read_rx3(e); p = os.path.join(WORK, *e['name'].split('/'))
                os.makedirs(os.path.dirname(p), exist_ok=True); open(p, 'wb').write(d)
                s.orig[e['name']] = md5(p); json.dump(s.orig, open(ORIG, 'w'))
                s.say('cikarildi: ' + p + '\nRx3Tools ile duzenle, AYNI YERE kaydet, sonra "Degisenleri big\'e yaz".')
            except Exception as ex: s.say('HATA: ' + traceback.format_exc())
        threading.Thread(target=w, daemon=True).start()

    def orig360(s, e):
        """Girdinin orijinal Xbox360 (RX3b) halini dondurur; big'deki bozuksa .bak'tan okur."""
        try: d = s.read_rx3(e)
        except Exception: d = b''
        if d[:4] != b'RX3b' and os.path.exists(s.big + '.bak'):
            d = fstool.read_entry(s.big + '.bak', e['name']) or d
        return d

    def do_restore(s):
        if not s.cur: return messagebox.showinfo('', 'Once soldan bir dosya sec.')
        e = s.cur
        def w():
            try:
                fstool.restore_entry(s.big, e['name'], s.say); s.cache.clear()
                with open(s.big, 'rb') as f: _, s.ents = fstool.read_index(f)
                s.orig.pop(e['name'], None); json.dump(s.orig, open(ORIG, 'w'))
            except Exception as ex: s.say('HATA: %s' % ex)
        threading.Thread(target=w, daemon=True).start()

    def do_fixswap(s):
        """Secili dosyanin (big'deki mevcut halinin) doku verilerine 16-bit swap uygulayip tekrar yazar. Bozuk (swap'siz) yazilmis dosyayi onarir."""
        if not s.cur: return messagebox.showinfo('', 'Once soldan bir dosya sec.')
        e = s.cur; raw = True
        def w():
            try:
                d = s.read_rx3(e)
                s.say('mevcut doku sirasi: %s' % rx3view.texture_order(d))
                nd = rx3view.swap_textures(d)
                tmp = os.path.join(WORK, '_test', *e['name'].split('/')); os.makedirs(os.path.dirname(tmp), exist_ok=True)
                open(tmp, 'wb').write(nd)
                fstool.import_files(s.big, [(e['name'], tmp)], s.say, raw=raw)
                s.cache.clear()
                with open(s.big, 'rb') as f: _, s.ents = fstool.read_index(f)
                s.say('BITTI. Listeden dosyaya tekrar tikla, onizleme duzeldi mi bak.')
            except Exception: s.say('HATA: ' + traceback.format_exc())
        threading.Thread(target=w, daemon=True).start()

    def do_rewrite(s):
        """Kontrol testi: secili dosyanin ORIJINAL icerigini (degistirmeden) secili modda (ham/sikistirmali) yeniden yazar."""
        if not s.cur: return messagebox.showinfo('', 'Once soldan bir dosya sec.')
        e = s.cur; raw = True
        def w():
            try:
                d = s.orig360(e)
                if d[:4] != b'RX3b': return s.say('HATA: orijinal icerik RX3b degil (%r)' % d[:4])
                tmp = os.path.join(WORK, '_test', *e['name'].split('/')); os.makedirs(os.path.dirname(tmp), exist_ok=True)
                open(tmp, 'wb').write(d)
                s.say('TEST: %s orijinal icerikle yeniden yaziliyor (%s)' % (e['name'], 'HAM' if raw else 'SIKISTIRMALI'))
                fstool.import_files(s.big, [(e['name'], tmp)], s.say, raw=raw)
                s.cache.clear()
                with open(s.big, 'rb') as f: _, s.ents = fstool.read_index(f)
                s.say('BITTI. Simdi oyunda bu formayi dene.')
            except Exception: s.say('HATA: ' + traceback.format_exc())
        threading.Thread(target=w, daemon=True).start()

    def do_check(s):
        def w():
            try: s.say('--- BH kontrol ---'); fstool.sync_bh(s.big, s.say, dry=True)
            except Exception as ex: s.say('HATA: %s' % ex)
        threading.Thread(target=w, daemon=True).start()

    def do_sync(s):
        def w():
            try: s.say('%d girdi esitlendi' % fstool.sync_bh(s.big, s.say))
            except Exception as ex: s.say('HATA: %s' % ex)
        threading.Thread(target=w, daemon=True).start()

    def do_replace(s):
        if not s.cur: return messagebox.showinfo('', 'Once soldan hangi dosyayi degistirecegini sec.')
        e = s.cur
        src = filedialog.askopenfilename(title='Rx3Tools ile olusturdugun yeni .rx3', filetypes=[('RX3', '*.rx3'), ('Hepsi', '*.*')])
        if not src: return
        new = open(src, 'rb').read()
        if new[:4] == b'RX3l':
            try:
                new = rx3view.transplant(s.orig360(e), new)
                s.say('PC (RX3l) dosyasi algilandi: dokular orijinal Xbox360 dosyasina aktarildi.')
            except Exception as ex:
                return messagebox.showerror('Cevrilemedi', 'RX3l -> 360 donusumu basarisiz:\n%s' % ex)
        elif new[:4] != b'RX3b':
            return messagebox.showerror('Hata', 'Bu bir RX3 dosyasi degil (basi %r).' % new[:4])
        if new[:8] == b'chunklzx': new = chunklzx.decompress(new)
        try:
            od = [x for x in rx3view.texture_order(new) if x in ('ok', 'unswapped')]
            if od and all(x == 'unswapped' for x in od):
                new = rx3view.swap_textures(new)
                s.say('UYARI: doku verisi PC sirasinda gorundu; otomatik olarak Xbox360 sirasina cevrildi. Onizlemeden kontrol et.')
            elif od and any(x == 'unswapped' for x in od):
                s.say('UYARI: bazi dokular dogru sirada, bazilari ters gorunuyor (%s). Elle kontrol et.' % od)
            else: s.say('doku sirasi kontrolu: %s' % od)
        except Exception as ex: s.say('doku sirasi kontrol edilemedi: %s' % ex)
        try:
            p = os.path.join(WORK, *e['name'].split('/')); os.makedirs(os.path.dirname(p), exist_ok=True)
            if e['name'] not in s.orig:   # orijinali referans olarak kaydet ki 'degisti' diye algilansin
                import tempfile
                orig = s.orig360(e); s.orig[e['name']] = hashlib.md5(orig).hexdigest(); json.dump(s.orig, open(ORIG, 'w'))
            open(p, 'wb').write(new)
            s.say('yerine konuldu: %s (%d bayt, eskisi %d). Simdi "2) Degisenleri big\'e yaz".' % (p, len(new), len(s.orig360(e))))
        except Exception: s.say('HATA: ' + traceback.format_exc())

    def pngdir(s, e): return os.path.join(WORK, '_png', *e['name'].split('/'))

    def do_png_export(s):
        if not s.cur: return messagebox.showinfo('', 'Once soldan bir dosya sec.')
        e = s.cur
        def w():
            try:
                d = s.orig360(e); src = os.path.join(WORK, '_png_src', *e['name'].split('/'))
                os.makedirs(os.path.dirname(src), exist_ok=True); open(src, 'wb').write(d)
                pd = s.pngdir(e); rx3png.export_pngs(s.cfg, src, pd, s.say)
                s.say('PNG klasoru: %s\nDuzenle, sonra "PNG klasorunden aktar".' % pd)
                if os.name == 'nt': os.startfile(pd)
            except Exception: s.say('HATA: ' + traceback.format_exc())
        threading.Thread(target=w, daemon=True).start()

    def do_png_import(s):
        if not s.cur: return messagebox.showinfo('', 'Once soldan bir dosya sec.')
        e = s.cur; pd = s.pngdir(e)
        if not os.path.isdir(pd): return messagebox.showinfo('', 'Once "PNG cikar (rx3c)" ile PNG klasorunu olustur.')
        def w():
            try:
                src = os.path.join(WORK, '_png_src', *e['name'].split('/'))
                out = rx3png.import_pngs(s.cfg, src, pd, os.path.join(WORK, '_png_out'), s.say)
                new = open(out, 'rb').read()
                if new[:4] == b'RX3l': new = rx3view.transplant(s.orig360(e), new); s.say('RX3l -> 360 aktarildi.')
                elif new[:4] != b'RX3b': raise ValueError('cikti RX3 degil: %r' % new[:4])
                s.say('doku sirasi: %s' % rx3view.texture_order(new))
                if s.autoswap.get(): new = rx3view.swap_textures(new); s.say('doku sirasi cevrildi')
                p = os.path.join(WORK, *e['name'].split('/')); os.makedirs(os.path.dirname(p), exist_ok=True)
                if e['name'] not in s.orig: s.orig[e['name']] = hashlib.md5(s.orig360(e)).hexdigest(); json.dump(s.orig, open(ORIG, 'w'))
                open(p, 'wb').write(new)
                s.say('hazir: %s (%d bayt). Kontrol et, sonra "2) Degisenleri big\'e yaz".' % (p, len(new)))
            except Exception: s.say('HATA: ' + traceback.format_exc())
        threading.Thread(target=w, daemon=True).start()

    def open_dir(s):
        os.makedirs(WORK, exist_ok=True)
        if os.name == 'nt': os.startfile(WORK)
        else: subprocess.Popen(['xdg-open', WORK])

    def open_rx3tools(s):
        exe = s.cfg.get('rx3tools')
        if not exe or not os.path.exists(exe):
            exe = filedialog.askopenfilename(title='Rx3Tools.exe sec', filetypes=[('exe', '*.exe')])
            if not exe: return
            s.cfg['rx3tools'] = exe; s.save_cfg()
        try:
            arg = []
            if s.cur:
                p = os.path.join(WORK, *s.cur['name'].split('/'))
                if os.path.exists(p): arg = [p]
            subprocess.Popen([exe] + arg)
        except Exception as ex: s.say('acilamadi: %s' % ex)

    def do_import(s):
        changed = []
        for name, h in s.orig.items():
            p = os.path.join(WORK, *name.split('/'))
            if os.path.exists(p) and md5(p) != h: changed.append((name, p))
        bad = [n for n, p in changed if open(p, 'rb').read(4) != b'RX3b']
        if bad: return messagebox.showerror('Durduruldu', 'Bu dosyalar Xbox360 (RX3b) formatinda degil, big\'e yazilmadi:\n' + '\n'.join(bad) + '\n\n"1b" dugmesiyle tekrar sec; PC dosyalari otomatik cevrilir.')
        if not changed: return messagebox.showinfo('', 'Degisen dosya yok (calisma klasorundeki dosyalar cikarildigi gibi).')
        if not messagebox.askyesno('Onay', '%d dosya big\'e yazilacak:\n%s\n\nYedek (.bak) alinacak. Devam?' % (len(changed), '\n'.join(n for n, _ in changed[:10]))): return
        def w():
            try:
                fstool.import_files(s.big, changed, s.say, raw=True)
                for name, p in changed: s.orig[name] = md5(p)
                json.dump(s.orig, open(ORIG, 'w')); s.cache.clear(); s.say('BITTI. Oyunda dene.')
                with open(s.big, 'rb') as f: _, s.ents = fstool.read_index(f)
            except Exception: s.say('HATA: ' + traceback.format_exc())
        threading.Thread(target=w, daemon=True).start()

if __name__ == '__main__': App().mainloop()
