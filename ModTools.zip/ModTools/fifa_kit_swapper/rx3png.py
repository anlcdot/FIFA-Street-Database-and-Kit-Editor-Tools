"""rx3c.exe (Rx3Tools'un motoru) ile PNG disa/ice aktarma. Komut sablonlari fsmod_ayar.json'dan degistirilebilir.
Sablon alanlari: {rx3} {png} {out} {game}"""
import os, shlex, subprocess, shutil, glob

DEFAULTS = {
    'game': 'fifa12pc',
    'export_args': '-export -i "{rx3}" -o "{out}" -game "{game}" -recursive -writeTexMetadata',
    'import_args': '-import -i "{png}" -o "{out}" -game "{game}" -recursive{meta}',
}

def find_rx3c(cfg, log=print):
    here = os.path.dirname(os.path.abspath(__file__))
    cands = [cfg.get('rx3c'), os.path.join(here, 'rx3c.exe')]
    t = cfg.get('rx3tools')
    if t: cands.append(os.path.join(os.path.dirname(t), 'rx3c.exe'))
    for c in cands:
        if c and os.path.isfile(c): return c
    log('rx3c.exe su yollarda arandi, bulunamadi:')
    for c in cands:
        if c: log('  ' + c)
    return None

def run(cfg, key, log, **kw):
    exe = find_rx3c(cfg, log)
    if not exe: raise RuntimeError('rx3c.exe bulunamadi (Rx3Tools.exe ile ayni klasorde olmali)')
    tpl = cfg.get(key) or DEFAULTS[key]
    kw.setdefault('game', cfg.get('game', DEFAULTS['game']))
    args = shlex.split(tpl.format(**kw), posix=False)
    args = [a[1:-1] if len(a) > 1 and a[0] == a[-1] == '"' else a for a in args]
    log('> rx3c ' + ' '.join(args))
    r = subprocess.run([exe] + args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
                       cwd=os.path.dirname(exe), creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    for line in ((r.stdout or '') + '\n' + (r.stderr or '')).splitlines():
        if line.strip(): log('  rx3c: ' + line)
    if r.returncode: raise RuntimeError('rx3c hata kodu %d' % r.returncode)
    return r

def export_pngs(cfg, rx3_path, outdir, log):
    shutil.rmtree(outdir, ignore_errors=True); os.makedirs(outdir, exist_ok=True)
    run(cfg, 'export_args', log, rx3=rx3_path, out=outdir, png='')
    pngs = sorted(glob.glob(os.path.join(outdir, '**', '*.png'), recursive=True))
    metas = sorted(glob.glob(os.path.join(outdir, '**', '*.csv'), recursive=True))
    log('%d PNG, %d CSV cikarildi: %s' % (len(pngs), len(metas), outdir))
    return pngs

def import_pngs(cfg, rx3_src, pngdir, outdir, log):
    """PNG klasorunu rx3c ile RX3'e cevirir; olusan .rx3 yolunu dondurur."""
    shutil.rmtree(outdir, ignore_errors=True); os.makedirs(outdir, exist_ok=True)
    
    # Alt klasorlerdeki PNG'leri ve metadata CSV dosyasini otomatik bul
    pngs = sorted(glob.glob(os.path.join(pngdir, '**', '*.png'), recursive=True))
    if not pngs:
        raise RuntimeError(f'PNG klasorunde hic .png dosyasi bulunamadi: {pngdir}')
    
    # PNG'lerin gercekte durdugu alt klasor (orn: .../kit_1_2_0.rx3/kit_1_2_0)
    actual_png_dir = os.path.dirname(pngs[0])
    
    metas = sorted(glob.glob(os.path.join(pngdir, '**', '*.csv'), recursive=True))
    meta = metas[0] if metas else ''
    meta_arg = f' -texFormatFile "{meta}"' if meta else ''
    log('metadata: ' + (meta if meta else 'yok (CSV bulunamadi)'))
    log('aktif PNG dizini: ' + actual_png_dir)

    # 1. Deneme: Dogrudan PNG'lerin bulundugu alt klasoru vererek dene
    run(cfg, 'import_args', log, rx3=rx3_src, png=actual_png_dir, out=outdir, meta=meta_arg)
    c = sorted(glob.glob(os.path.join(outdir, '**', '*.rx3'), recursive=True), key=os.path.getmtime)
    
    # 2. Deneme: Eger uretmediyse ust klasoru (pngdir) vererek dene
    if not c and actual_png_dir != pngdir:
        log('Alt klasorle .rx3 olusmadi, ust klasor ile tekrar deneniyor...')
        run(cfg, 'import_args', log, rx3=rx3_src, png=pngdir, out=outdir, meta=meta_arg)
        c = sorted(glob.glob(os.path.join(outdir, '**', '*.rx3'), recursive=True), key=os.path.getmtime)

    if not c:
        log('--- import sonrasi icerik (cikti) ---')
        for root, _, files in os.walk(outdir):
            for f in files: log('  ' + os.path.relpath(os.path.join(root, f), outdir))
        log('--- PNG klasoru (tum alt dosyalar) ---')
        for root, _, files in os.walk(pngdir):
            for f in files: log('  ' + os.path.relpath(os.path.join(root, f), pngdir))
        raise RuntimeError('rx3c .rx3 uretmedi; yukaridaki listeyi gonder')
    return c[-1]