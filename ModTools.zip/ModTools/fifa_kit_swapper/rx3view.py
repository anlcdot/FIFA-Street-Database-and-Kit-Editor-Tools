"""RX3 (Xbox360, big-endian) doku okuyucu + onizleme (DXT1/3/5 -> PNG). Bagimliliksiz."""
import struct, zlib

TEX_TYPE = 0x7A0B60DA
FORMATS = {0: 'DXT1', 1: 'DXT3', 2: 'DXT5', 3: 'ARGB8 (tahmin)'}

def parse(d):
    if d[:3] != b'RX3': raise ValueError('RX3 degil')
    n = struct.unpack('>I', d[12:16])[0]
    secs = [struct.unpack('>4I', d[16+i*16:32+i*16]) for i in range(n)]
    s0 = secs[0][1]
    cnt = struct.unpack('>I', d[s0:s0+4])[0]
    texsecs = [s for s in secs[1:] if s[0] == TEX_TYPE]
    out = []
    for i in range(min(cnt, len(texsecs))):
        p = s0 + 0x10 + 16*i
        size, _, fmt, _, w, h, _, mips = struct.unpack('>IBBHHHBB', d[p:p+14]) if False else (None,)*8
        size = struct.unpack('>I', d[p:p+4])[0]; fmt = d[p+5]
        w, h = struct.unpack('>HH', d[p+8:p+12]); mips = d[p+15]
        out.append(dict(index=i, offset=texsecs[i][1], size=texsecs[i][2], fmt=fmt,
                        fmtname=FORMATS.get(fmt, 'bilinmiyor(%d)' % fmt), w=w, h=h, mips=mips))
    return out

def swap16(b):
    a = bytearray(len(b)); a[0::2] = b[1::2]; a[1::2] = b[0::2]; return a

def _c565(c):
    return (((c >> 11) & 31) * 255 // 31, ((c >> 5) & 63) * 255 // 63, (c & 31) * 255 // 31)

def _col_block(blk):
    c0, c1, idx = struct.unpack('<HHI', blk)
    p0, p1 = _c565(c0), _c565(c1)
    if c0 > c1:
        pal = [p0, p1, tuple((2*a+b)//3 for a, b in zip(p0, p1)), tuple((a+2*b)//3 for a, b in zip(p0, p1))]
    else:
        pal = [p0, p1, tuple((a+b)//2 for a, b in zip(p0, p1)), (0, 0, 0)]
    return [pal[(idx >> (2*i)) & 3] for i in range(16)]

def decode_dxt(data, w, h, fmt):
    """data: 16-bit swap EDILMIS blok verisi. RGB bytes dondurur (alfa gri zeminle karistirilir)."""
    bs = 8 if fmt == 0 else 16
    bw, bh = (w+3)//4, (h+3)//4
    rows = [bytearray(w*3) for _ in range(h)]
    p = 0
    for by in range(bh):
        for bx in range(bw):
            blk = data[p:p+bs]; p += bs
            if len(blk) < bs: break
            if fmt == 0: px = _col_block(blk); al = None
            else:
                px = _col_block(blk[8:])
                if fmt == 1:
                    v = int.from_bytes(blk[:8], 'little'); al = [((v >> (4*i)) & 15)*17 for i in range(16)]
                else:
                    a0, a1 = blk[0], blk[1]; v = int.from_bytes(blk[2:8], 'little')
                    tab = [a0, a1] + ([(( 6-i)*a0 + (i)*a1)//7 for i in range(1, 7)] if a0 > a1 else
                                      [((5-i)*a0 + i*a1)//5 for i in range(1, 5)] + [0, 255])
                    al = [tab[(v >> (3*i)) & 7] for i in range(16)]
            for y in range(4):
                yy = by*4+y
                if yy >= h: break
                row = rows[yy]
                for x in range(4):
                    xx = bx*4+x
                    if xx >= w: break
                    r, g, b = px[y*4+x]
                    if al is not None:
                        a = al[y*4+x]; r = (r*a + 200*(255-a))//255; g = (g*a + 200*(255-a))//255; b = (b*a + 200*(255-a))//255
                    row[xx*3:xx*3+3] = bytes((r, g, b))
    return rows

def png_bytes(rows, w, h):
    raw = b''.join(b'\0' + bytes(r) for r in rows)
    def ch(t, d): return struct.pack('>I', len(d)) + t + d + struct.pack('>I', zlib.crc32(t + d) & 0xffffffff)
    return b'\x89PNG\r\n\x1a\n' + ch(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 2, 0, 0, 0)) + ch(b'IDAT', zlib.compress(raw, 3)) + ch(b'IEND', b'')

def preview_png(d, tex, maxdim=512):
    """Doku mip0'ini PNG olarak dondurur. Desteklenmeyen formatta None."""
    if tex['fmt'] not in (0, 1, 2): return None
    w, h = tex['w'], tex['h']
    n = (w*h//2) if tex['fmt'] == 0 else w*h
    data = swap16(d[tex['offset']:tex['offset']+n])
    rows = decode_dxt(data, w, h, tex['fmt'])
    f = 1
    while max(w, h)//f > maxdim: f *= 2
    if f > 1:
        rows = [bytearray(b''.join(bytes(r[x*3:x*3+3]) for x in range(0, w, f))) for r in rows[::f]]
        w, h = (w+f-1)//f, (h+f-1)//f
    return png_bytes(rows, w, h)

def _endian(d):
    return '>' if d[3:4] == b'b' else '<' if d[3:4] == b'l' else None

def _texsecs(d):
    e = _endian(d)
    n = struct.unpack(e+'I', d[12:16])[0]
    secs = [struct.unpack(e+'4I', d[16+i*16:32+i*16]) for i in range(n)]
    return e, secs, [s for s in secs[1:] if s[0] == TEX_TYPE]

def transplant(orig, pc):
    """PC formatindaki (RX3l) dosyadan dokulari alip orijinal Xbox360 (RX3b) dosyasinin icine koyar.
    Doku sayisi ve her dokunun boyutu ayni olmali. Veri 16-bit swap'lanarak yazilir."""
    if _endian(orig) != '>': raise ValueError('orijinal dosya RX3b degil')
    if _endian(pc) != '<': raise ValueError('yeni dosya RX3l degil')
    _, _, ot = _texsecs(orig); _, _, pt = _texsecs(pc)
    if len(ot) != len(pt): raise ValueError('doku sayisi farkli (orijinal %d, yeni %d)' % (len(ot), len(pt)))
    out = bytearray(orig)
    for i, (a, b) in enumerate(zip(ot, pt)):
        if a[2] != b[2]: raise ValueError('doku #%d boyutu farkli (orijinal %d, yeni %d bayt): boyut/format/mip degismis olmali' % (i, a[2], b[2]))
        out[a[1]:a[1]+a[2]] = swap16(pc[b[1]:b[1]+b[2]])
    return bytes(out)

def _roughness(raw, w, fmt):
    """Verilen (swap'lanmamis varsayilan) blok verisini cozup yatay komsu piksel farki ortalamasini dondurur (kucuk = duzgun)."""
    bs = 8 if fmt == 0 else 16
    rows_blocks = 32
    n = (w // 4) * rows_blocks * bs
    chunk = raw[:n]
    rows = decode_dxt(chunk, w, rows_blocks * 4, fmt)
    tot = cnt = 0
    for r in rows:
        g = r[1::3]
        for i in range(1, len(g)):
            tot += abs(g[i] - g[i-1]); cnt += 1
    return tot / max(cnt, 1)

def texture_order(d):
    """Her DXT dokusu icin 'ok' (Xbox360 swap'li, dogru), 'unswapped' (PC sirasi) veya 'unclear' dondurur."""
    res = []
    for t in parse(d):
        if t['fmt'] not in (0, 1, 2): res.append('skip'); continue
        raw = d[t['offset']:t['offset']+t['size']]
        a = _roughness(bytes(swap16(raw[:t['w']//4*32*16])), t['w'], t['fmt'])   # swap'li varsayim (dogru olmasi beklenen)
        b = _roughness(raw[:t['w']//4*32*16], t['w'], t['fmt'])                    # swap'siz varsayim
        if abs(a - b) < 0.5: res.append('unclear')
        else: res.append('ok' if a < b else 'unswapped')
    return res

def swap_textures(d):
    """Tum doku bolumlerine 16-bit swap uygular (kendi tersi)."""
    e, secs, ts = _texsecs(d)
    out = bytearray(d)
    for s in ts: out[s[1]:s[1]+s[2]] = swap16(d[s[1]:s[1]+s[2]])
    return bytes(out)
