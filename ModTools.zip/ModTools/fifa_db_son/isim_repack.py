"""playernames heap'ini yeniden paketler: sikistirilmis isimler sirayla yazilir, isim
isaretcileri (type 13 ofset alani) yeni yerlere gore guncellenir. Tree (heap basi) aynen kalir."""
def repack_name(t, rec_index, text):
    """t: fifadb.Table (playernames), rec_index: satir, text: yeni isim. Tum isimler korunur, hedef isim degisir."""
    nh = t.names
    f = t.fmap['name']
    target = t._raw(t.recs[rec_index], f)
    if target == 0xffffffff: raise ValueError('bu kayitta isim yok')
    offs = sorted(set(t._raw(r, f) for r in t.recs if t._raw(r, f) != 0xffffffff))
    old = {o: nh.decode(o, 1) for o in offs}          # eski metinler (eski heap'ten)
    old[target] = text
    orig_len = len(t.heap)
    H = bytearray(t.heap[:nh.tree_len])
    newoff = {}
    for o in offs:
        newoff[o] = len(H)
        H += nh.encode(old[o], 1)
    if len(H) > orig_len:
        raise ValueError('isim heap buyuyor (%d > %d bayt); daha kisa bir ad dene' % (len(H), orig_len))
    H += bytes(orig_len - len(H))                    # heap boyutu degismesin (oyun boyuta duyarli olabilir)
    for r in t.recs:
        o = t._raw(r, f)
        if o != 0xffffffff: t._put(r, f, newoff[o])
    t.heap = H
    if hasattr(nh, '_sorted'): del nh._sorted
    t.dirty = True
    return len(H)


def add_name_repack(t, text):
    """playernames tablosuna yeni bir isim ekler. Heap boyutu sabit kalir (paketleme ile).
    Yeni nameid dondurur. Eski isimler ve paylasimlar korunur."""
    nh = t.names
    f = t.fmap['name']
    orig_len = len(t.heap)
    offs = sorted(set(t._raw(r, f) for r in t.recs if t._raw(r, f) != 0xffffffff))
    old = {o: nh.decode(o, 1) for o in offs}
    KEY = ('NEW',)
    entries = [(o, old[o]) for o in offs] + [(KEY, text)]
    H = bytearray(t.heap[:nh.tree_len]); newoff = {}
    for k, s in entries:
        newoff[k] = len(H); H += nh.encode(s, 1)
    if len(H) > orig_len:
        raise ValueError('isim heap buyuyor (%d > %d bayt); daha kisa bir ad dene' % (len(H), orig_len))
    H += bytes(orig_len - len(H))
    for r in t.recs:
        o = t._raw(r, f)
        if o != 0xffffffff: t._put(r, f, newoff[o])
    t.heap = H
    if hasattr(nh, '_sorted'): del nh._sorted
    nid = max(t.get(i, 'nameid') for i in range(t.cnt)) + 1
    r = t.new_record(t.cnt - 1)
    t._put(t.recs[r], f, newoff[KEY])
    t._put(t.recs[r], t.fmap['nameid'], nid - t.fmap['nameid'].lo)
    t.dirty = True
    return nid
