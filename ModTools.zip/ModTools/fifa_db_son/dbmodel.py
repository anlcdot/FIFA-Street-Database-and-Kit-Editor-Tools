# -*- coding: utf-8 -*-
"""Takim / oyuncu veri modeli. Arayuzden bagimsiz; test edilebilir."""
import os, shutil, glob
import fifadb

class FifaModel:
    def __init__(self, pc_path, pc_meta, loc_path=None, loc_meta=None):
        self.pc_path = pc_path
        self.pc = fifadb.FifaDB(open(pc_path, 'rb').read(), fifadb.load_meta(pc_meta))
        self.loc = None; self.loc_path = loc_path
        if loc_path:
            self.loc = fifadb.FifaDB(open(loc_path, 'rb').read(), fifadb.load_meta(loc_meta))
        self._loc_index = None
        self._names = None
        self._build_indexes()

    # ---------- indeksler ----------
    def _build_indexes(self):
        pn = self.pc['playernames']
        self.name_row = {}                       # nameid -> satir
        for i in range(pn.cnt):
            self.name_row.setdefault(pn.get(i, 'nameid'), i)
        self.player_row = {}                     # playerid -> satir
        pl = self.pc['players']
        for i in range(pl.cnt):
            self.player_row.setdefault(pl.get(i, 'playerid'), i)
        self.team_players = {}                   # teamid -> [playerid]
        tl = self.pc['teamplayerlinks']
        for i in range(tl.cnt):
            self.team_players.setdefault(tl.get(i, 'teamid'), []).append(tl.get(i, 'playerid'))
        if self.loc:
            lt = self.loc.tables['vCJG']
            self._loc_index = {}
            for i in range(lt.cnt):
                self._loc_index.setdefault(lt.get(i, 'stringid'), i)

    # ---------- metin yardimcilari ----------
    def pc_text(self, nameid):
        if nameid not in self.name_row: return ''
        return self.pc['playernames'].get(self.name_row[nameid], 'name')

    def set_pc_text(self, nameid, text):
        """Ayni nameid'yi kullanan TUM oyuncularin adini degistirir (paylasimli isim)."""
        if nameid not in self.name_row: raise KeyError('nameid %s yok' % nameid)
        t = self.pc['playernames']; row = self.name_row[nameid]
        try:
            t.set(row, 'name', text)                 # once yerinde (slot icinde) dene
        except ValueError:
            # slot sigmadi: heap'i yeniden paketle (tum isimler korunur, yalniz bu isim degisir)
            import isim_repack
            isim_repack.repack_name(t, row, text)

    def set_player_name(self, pid, field, text):
        """Tek bir oyuncunun ad alanini (firstnameid/lastnameid/commonnameid) degistirir.
        Ad kaydi baska oyuncular tarafindan da kullaniliyorsa, once yeni bir ad kaydi acilip
        yalnizca bu oyuncunun alani ona baglanir; diger oyuncular etkilenmez."""
        import isim_repack
        pl = self.pc['players']
        prow = self.player_row[pid]
        nid = pl.get(prow, field)
        names = ('firstnameid', 'lastnameid', 'commonnameid')
        users = 0
        for i in range(pl.cnt):
            for k in names:
                if pl.get(i, k) == nid: users += 1
        if users <= 1:
            self.set_pc_text(nid, text)          # yalniz bu oyuncu kullaniyor: yerinde degistir
            return nid
        t = self.pc['playernames']
        new_nid = isim_repack.add_name_repack(t, text)
        self.name_row = {}
        for i in range(t.cnt):
            self.name_row.setdefault(t.get(i, 'nameid'), i)
        pl._put(pl.recs[prow], pl.fmap[field], new_nid - pl.fmap[field].lo)
        pl.dirty = True
        return new_nid

    def player_name(self, pid):
        pl = self.pc['players']; i = self.player_row[pid]
        common = pl.get(i, 'commonnameid')
        if common: return self.pc_text(common)
        return (self.pc_text(pl.get(i, 'firstnameid')) + ' ' + self.pc_text(pl.get(i, 'lastnameid'))).strip()

    # ---------- takimlar ----------
    def team_ids(self):
        t = self.pc['teams']
        return [(t.get(i, 'teamid'), i) for i in range(t.cnt)]

    def team_pc_name(self, row):
        return self.pc['teams'].get(row, 'teamname')

    def team_loc_key(self, teamid):
        return 'TeamName_%d' % teamid

    def team_loc_name(self, teamid):
        if not self.loc: return None
        key = self.team_loc_key(teamid)
        if key not in self._loc_index: return None
        return self.loc.tables['vCJG'].get(self._loc_index[key], 'sourcetext')

    def set_team_loc_name(self, teamid, text, abbr=None):
        """Oyunda gorunen tam adi degistirir. Ayni takimin tam ad anahtarlari da guncellenir:
        TeamName_<id>, CT_TeamName_<id>, TeamName_Abbr<n>_<id> (ancak kisa kodlar, ornegin ARS, dokunulmaz)."""
        import re
        if abbr:
            code = abbr.strip().upper()
            if len(code) != 3 or not code.isalpha() or not code.isascii():
                raise ValueError('Kısaltma tam 3 harf olmalı (örn. MAL)')
            abbr = code
        key = self.team_loc_key(teamid)
        if not self.loc or key not in self._loc_index:
            raise KeyError('yerel dilde %s yok' % key)
        t = self.loc.tables['vCJG']
        t.set(self._loc_index[key], 'sourcetext', text)
        pat = re.compile(r'^(CT_TeamName_|TeamName_Abbr\d+_)%d$' % teamid)
        for k, i in self._loc_index.items():
            if not pat.match(k):
                continue
            if len(t.get(i, 'sourcetext')) > 3:      # tam ad anahtarlari
                t.set(i, 'sourcetext', text)
            else:                                    # 3 harfli kisa kod
                if abbr:
                    code = abbr
                elif len(text) >= 3:
                    code = text[:3].upper()          # bos birakilirsa yeni adin ilk 3 harfi
                else:
                    continue
                t.set(i, 'sourcetext', code)

    # ---------- oyuncular ----------
    def players_of_team(self, teamid):
        return [self.player_row[p] for p in self.team_players.get(teamid, []) if p in self.player_row]

    # ---------- kaydet ----------
    def save(self, pc_out=None, loc_out=None):
        pc_out = pc_out or self.pc_path
        if os.path.exists(pc_out) and not os.path.exists(pc_out + '.bak'):
            shutil.copy2(pc_out, pc_out + '.bak')
        open(pc_out, 'wb').write(self.pc.dump())
        if self.loc:
            loc_out = loc_out or self.loc_path
            if os.path.exists(loc_out) and not os.path.exists(loc_out + '.bak'):
                shutil.copy2(loc_out, loc_out + '.bak')
            open(loc_out, 'wb').write(self.loc.dump())
